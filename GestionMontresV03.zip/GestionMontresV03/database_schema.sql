-- =====================================================================
--  Schéma de la base "bijouterie_db" (XAMPP / MySQL 8)
--  ديرو Import لهاد الملف فـ phpMyAdmin (كيصاوب القاعدة + الجداول + بيانات).
--  النمذجة العلائقية للتسلسل الهرمي:
--    • montre    : الساعة + خصائص الميكانيزم (مع عمود mec_type كـ discriminateur)
--    • accessoire: الإكسسوارات المرتبطة بالساعة (علاقة 1-N, ON DELETE CASCADE)
--
--  Contraintes d'intégrité :
--    • PK : id_montre / id_accessoire (AUTO_INCREMENT)
--    • FK : accessoire.id_montre → montre.id_montre (ON DELETE CASCADE)
--    • INDEX explicite sur la FK (accès rapide aux accessoires d'une montre)
--    • CHECK : les valeurs (montre, mécanisme, accessoires) sont >= 0
--      (MySQL 8.0.16+). Défense en profondeur : la validation métier reste
--      centralisée dans le Service (Catalogue.validerMontre).
-- =====================================================================
CREATE DATABASE IF NOT EXISTS bijouterie_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bijouterie_db;

DROP TABLE IF EXISTS accessoire;
DROP TABLE IF EXISTS montre;

CREATE TABLE montre (
    id_montre         INT AUTO_INCREMENT PRIMARY KEY,
    modele            VARCHAR(120) NOT NULL,
    valeur_base       DOUBLE NOT NULL DEFAULT 0,
    -- نوع الميكانيزم (discriminateur للتسلسل الهرمي Mecanisme)
    mec_type          ENUM('ANALOGIQUE','DIGITAL','DOUBLE') NOT NULL DEFAULT 'ANALOGIQUE',
    mec_valeur_base   DOUBLE NOT NULL DEFAULT 0,
    mec_heure         TIME NOT NULL DEFAULT '12:00:00',
    -- Options des mécanismes = VRAIES valeurs (null = option inactive) :
    --   • mec_date         DATE : date affichée (Analogique/Double)
    --   • mec_heure_reveil TIME : heure de réveil (Digital/Double)
    mec_date          DATE NULL,
    mec_heure_reveil  TIME NULL,
    -- ألا تكون الأثمان سالبة (قاعدة عمل منعكسة في قاعدة البيانات)
    CONSTRAINT chk_montre_valeur_base_non_neg CHECK (valeur_base >= 0),
    CONSTRAINT chk_mec_valeur_base_non_neg   CHECK (mec_valeur_base >= 0)
);

CREATE TABLE accessoire (
    id_accessoire INT AUTO_INCREMENT PRIMARY KEY,
    id_montre     INT NOT NULL,
    type          ENUM('Boitier','Bracelet','Fermoir','Vitre') NOT NULL,
    valeur_base   DOUBLE NOT NULL DEFAULT 0,
    -- فهرس صريح على المفتاح الأجنبي (الوصول السريع لإكسسوارات ساعة)
    INDEX idx_accessoire_montre (id_montre),
    -- ملي تمسح ساعة، إكسسواراتها كيتمسحو أوتوماتيكياً
    FOREIGN KEY (id_montre) REFERENCES montre(id_montre) ON DELETE CASCADE,
    CONSTRAINT chk_accessoire_valeur_base_non_neg CHECK (valeur_base >= 0)
);

-- بيانات تجريبية باش تلقى شي حاجة فاش تشغّل
INSERT INTO montre (modele, valeur_base, mec_type, mec_valeur_base, mec_heure, mec_date, mec_heure_reveil) VALUES
    ('Classic Or',      120, 'ANALOGIQUE',  80, '10:10:00', '2025-05-17', NULL),
    ('Sport Digital',    60, 'DIGITAL',     50, '08:30:15', NULL,         '07:30:00'),
    ('Prestige Double', 200, 'DOUBLE',     160, '14:45:00', '2025-05-17', '07:30:00');

INSERT INTO accessoire (id_montre, type, valeur_base) VALUES
    (1,'Boitier',150),(1,'Bracelet',90),(1,'Vitre',40),
    (2,'Boitier',70),(2,'Bracelet',45),
    (3,'Boitier',220),(3,'Bracelet',140),(3,'Fermoir',60),(3,'Vitre',80);
