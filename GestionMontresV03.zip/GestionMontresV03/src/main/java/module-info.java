/*
 * module-info.java — JPMS (Java Platform Module System).
 *
 * لماذا نحتاج هذه التصريحات؟
 *   • requires: كل مكتبة خارجية (JavaFX، JDBC، HikariCP) يجب التصريح بها
 *     وإلا اعتُبرت غير مرئية في نظام الوحدات (لا يمكن استعمالها).
 *   • opens: الـ FXMLLoader يملأ حقول الـ Controllers (الموسومة @FXML)
 *     و يملأ root المشهد عبر «الانعكاس» (reflection)؛ وبدون opens على
 *     الحزمة، يمنع JPMS هذا الانعكاس فيفشل تحميل أي FXML.
 *   • exports: يجعل فقط الحزمة الجذر (com.bijouterie) متاحة خارجياً —
 *     تقليص لسطح الواجهة (encapsulation قوية للوحدات).
 */
module com.bijouterie {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;          // JDBC (الاتصال بـ MySQL)
    requires java.logging;      // journalisation des erreurs (sécurité PHASE 4)
    requires com.zaxxer.hikari; // Connection Pool

    opens com.bijouterie to javafx.fxml, javafx.graphics;
    opens com.bijouterie.controller to javafx.fxml;

    exports com.bijouterie;
}
