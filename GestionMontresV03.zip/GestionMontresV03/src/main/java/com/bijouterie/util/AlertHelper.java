package com.bijouterie.util;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.stage.Window;
import java.util.Optional;

/**
 * أداة الرسائل (error/warning/info/confirm) — مبدأ DRY.
 *
 * الهدف: كل النوافذ/التأكيدات تُبنى من مكان واحد بأساليب جاهزة.
 * لماذا؟ تجنّب تكرار كود إنشاء Alert في كل Controller، وضمان التناسق:
 *   • عنوان/ترويسة واضحان لكل نوع رسالة،
 *   • initOwner(o) يجعل الرسالة «ابنة» النافذة الأم (تظهر فوقها صحيحاً)،
 *   • theme(a) يجعلها متناسقة بصرياً مع الثيم الحالي (نهاري/ليلي) —
 *     بدونها كانت Alert/Dialog كتبان دايماً بمظهر Modena الافتراضي
 *     بغض النظر عن الوضع المفعّل فباقي التطبيق (Scene خاصة بيها وحدها).
 * الفائدة: تبقى معالجة أخطاء الواجهة موحّدة وسهلة التعديل في نقطة واحدة.
 */
public final class AlertHelper {
    private AlertHelper() {}

    public static void error(Window o, String h, String c)   { show(Alert.AlertType.ERROR, o, "Erreur", h, c); }
    public static void warning(Window o, String h, String c) { show(Alert.AlertType.WARNING, o, "Attention", h, c); }
    public static void info(Window o, String h, String c)    { show(Alert.AlertType.INFORMATION, o, "Information", h, c); }

    public static boolean confirm(Window o, String h, String c) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        initOwnerSiPossible(a, o);
        a.setTitle("Confirmation"); a.setHeaderText(h); a.setContentText(c);
        theme(a);
        Optional<ButtonType> r = a.showAndWait();
        return r.isPresent() && r.get() == ButtonType.OK;
    }

    private static void show(Alert.AlertType t, Window o, String title, String h, String c) {
        Alert a = new Alert(t);
        initOwnerSiPossible(a, o);
        a.setTitle(title); a.setHeaderText(h); a.setContentText(c);
        theme(a);
        a.showAndWait();
    }

    /**
     * Rattache la boîte de dialogue à son propriétaire uniquement si celui-ci
     * est « prêt » (possède déjà une Scene). Sans ce garde-fou, JavaFX lève une
     * NullPointerException dans HeavyweightDialog.updateStageBindings quand le
     * Stage propriétaire n'a pas encore de Scene — typiquement lors d'une erreur
     * au tout démarrage, avant primaryStage.setScene(...). Dans ce cas on affiche
     * simplement la boîte de dialogue sans parent plutôt que de faire crasher
     * l'application.
     */
    private static void initOwnerSiPossible(Dialog<?> dialog, Window owner) {
        if (owner == null) return;
        try {
            if (owner.getScene() != null) {
                dialog.initOwner(owner);
            }
        } catch (RuntimeException e) {
            // Dernier filet : ne jamais laisser l'attache au parent empêcher
            // le message d'erreur de s'afficher.
        }
    }

    /**
     * كنسمعو لـ sceneProperty ديال الـ DialogPane: ملي تبان الـ Scene
     * (عندها Stage منفصل، ما كترثش الثيم ديال النافذة الأم) كنطبّقو
     * عليها الثيم الحالي عبر Theme.applyTo(...) — بلا ما نربطوها فأي
     * لائحة دائمة (شوف التعليق فـ Theme.applyTo لسبب هاد الاختيار).
     */
    private static void theme(Dialog<?> dialog) {
        if (dialog == null) return;
        dialog.getDialogPane().sceneProperty().addListener(
                (obs, oldScene, newScene) -> {
                    if (newScene != null) Theme.applyTo(newScene);
                });
    }
}
