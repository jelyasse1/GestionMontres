package com.bijouterie.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * ============================================================
 *  ExcelExporter — تصدير لـ Excel (.xlsx) بدون أي مكتبة خارجية
 * ============================================================
 *  ملف .xlsx هو فالحقيقة أرشيف ZIP فيه ملفات XML.
 *  هنا كنبنيوه يدوياً بـ java.util.zip => كيتقرا عادي فـ Excel / LibreOffice.
 *  كنستعملو "inlineStr" باش ما نحتاجوش sharedStrings (أبسط).
 */
public final class ExcelExporter {

    private ExcelExporter() {}

    public static void export(File file, String sheetName,
                              String[] headers, List<String[]> rows) throws IOException {
        try (OutputStream os = new BufferedOutputStream(Files.newOutputStream(file.toPath()));
             ZipOutputStream zip = new ZipOutputStream(os)) {

            put(zip, "[Content_Types].xml", contentTypes());
            put(zip, "_rels/.rels", rootRels());
            put(zip, "xl/workbook.xml", workbook(sheetName));
            put(zip, "xl/_rels/workbook.xml.rels", workbookRels());
            put(zip, "xl/worksheets/sheet1.xml", sheet(headers, rows));
        }
    }

    private static void put(ZipOutputStream zip, String name, String content) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
             + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
             + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
             + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
             + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
             + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
             + "</Types>";
    }

    private static String rootRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
             + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
             + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
             + "</Relationships>";
    }

    private static String workbook(String sheetName) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
             + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
             + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
             + "<sheets><sheet name=\"" + xml(sheetName) + "\" sheetId=\"1\" r:id=\"rId1\"/></sheets>"
             + "</workbook>";
    }

    private static String workbookRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
             + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
             + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
             + "</Relationships>";
    }

    private static String sheet(String[] headers, List<String[]> rows) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        int r = 1;
        sb.append(rowXml(r++, headers));
        for (String[] row : rows) sb.append(rowXml(r++, row));
        sb.append("</sheetData></worksheet>");
        return sb.toString();
    }

    private static String rowXml(int rowNum, String[] cells) {
        StringBuilder sb = new StringBuilder("<row r=\"" + rowNum + "\">");
        for (int c = 0; c < cells.length; c++) {
            String ref = colLetter(c) + rowNum;
            String val = cells[c] == null ? "" : cells[c];
            sb.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
              .append(xml(val)).append("</t></is></c>");
        }
        return sb.append("</row>").toString();
    }

    private static String colLetter(int index) {
        StringBuilder sb = new StringBuilder();
        index++; // 1-based
        while (index > 0) {
            int rem = (index - 1) % 26;
            sb.insert(0, (char) ('A' + rem));
            index = (index - 1) / 26;
        }
        return sb.toString();
    }

    private static String xml(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            // XML 1.0 interdit les caractères de contrôle C0 sauf tabulation,
            // saut de ligne et retour chariot — on les retire au lieu de produire
            // un classeur que Excel refuse d'ouvrir (collage de texte exotique).
            if (c >= 0x20 || c == '\t' || c == '\n' || c == '\r') {
                switch (c) {
                    case '&'  -> sb.append("&amp;");
                    case '<'  -> sb.append("&lt;");
                    case '>'  -> sb.append("&gt;");
                    case '"'  -> sb.append("&quot;");
                    default   -> sb.append(c);
                }
            }
        }
        return sb.toString();
    }
}
