package com.bijouterie.util;

import javafx.application.Platform;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBoxBase;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.paint.Color;
import javafx.stage.PopupWindow;
import javafx.stage.Window;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ============================================================
 *  Theme — مدبّر الوضع الليلي / النهاري (Dark / Light Mode)
 * ============================================================
 *  ROOT CAUSE (المنيو اللي كتبقى فارغة حتى Hover — فالوضعين بجوج):
 *  ---------------------------------------------------------------
 *  MenuBar/Menu كيبنيو المحتوى ديال popup ديالهم (ContextMenuContent:
 *  الـ Label/Graphic ديال كل MenuItem) مرة وحدة فقط، ملي كيتفتح Menu
 *  لأول مرة، ومن بعد كيعاودو يستعملوه (show/hide) بلا ما يبنيوه
 *  مرة أخرى — تماما بحال خلايا TableView المعاد استعمالها. هاد
 *  المحتوى، زيادة على هادشي، كيتخزن (cache) بصريا من طرف الـ Skin
 *  لأسباب أداء (rendering cache)، فبعد أول رسم، تغيير stylesheet/
 *  style-class بعدها (applyCss()+layout()) ما كيجبرش هاد الـ Node
 *  المخبأ يعاود يترسم — كيبقى عارض نفس البيكسلات القديمة. الاستثناء
 *  الوحيد هو العنصر تحت الماوس (:hover)، لأن تغيير pseudo-class
 *  كيجبر الـ Skin يعاود يرسم هاد العنصر بالذات فوراً (ولهذا بالضبط
 *  كان كيبان صحيح غير العنصر المحوَّم عليه، والباقي خالي).
 *
 *  التجربة بتّت هاد التفسير: أول فتح للـ Menu (فأي وضع، نهاري ولا
 *  ليلي) كيبان صحيح 100% لأن المحتوى كيتبنى تلقائيا تحت الستايل
 *  الحالي؛ المشكل كيبان غير من بعد أول toggle، ملي كيتفتح Menu
 *  كان مبني من قبل تحت وضع مختلف.
 *
 *  المحاولة السابقة (Platform.runLater + "nudge" على opacity ديال
 *  الـ PopupWindow) ماكانتش كافية لأنها كتأثر غير على الـ compositing
 *  ديال النافذة ككل، ماشي على الـ render cache الداخلي لكل Node/Label
 *  بوحدو.
 *
 *  الحل الجذري (خطوة 1): بدل ما نحاولو "نصلحو" نفس popup content اللي
 *  تصاوب من قبل، كنهدمو الـ Skin ديال MenuBar كاملة ونعاود نبنيها
 *  (setSkin(null) ثم setSkin(new MenuBarSkin(...))) — هادشي كيرمي كل
 *  Node مخبأ (بما فيه الـ ContextMenuContent المخبأة ديال كل Menu).
 *
 *  خطوة 2 (زيادة على خطوة 1، بعد ما تبيّن أنها وحدها ماكافيتش فكل
 *  الحالات فهاد البيئة): نفرضو -fx-text-fill مباشرة (inline style)
 *  على كل MenuItem فـ applyMenuItemColors() — آلية لا تعتمد إطلاقاً
 *  على CSS variable resolution عبر حدود popup Scene ولا على أي
 *  render cache: تعيين .setStyle() هو mutation مباشر على الخاصية
 *  الستايلبل ديال العنصر بالذات، وكيتطبق فوراً بغض النظر عن أي سبب
 *  دقيق وراء تعطل الـ cascade فهاد الحالة بالضبط.
 * ============================================================
 */
public final class Theme {

    private static final Logger LOG = Logger.getLogger(Theme.class.getName());

    private static final String STYLESHEET = "/css/styles.css";
    private static final String DARK_CLASS = "dark";

    private static boolean dark = false;
    private static final Set<Scene> scenes =
            Collections.newSetFromMap(new WeakHashMap<>());
    // WeakHashMap: ما كنشدوش المرجع إلا ملي الـ MenuBar لازالت حية،
    // بلا تسريب ميموري إذا تسدت النافذة اللي فيها.
    private static final Set<MenuBar> menuBars = Collections.newSetFromMap(new WeakHashMap<>());

    // Couleur "encre" résolue depuis la feuille de style (token -ink) — source
    // unique de vérité, calculée une seule fois par mode (styles constants).
    private static String inkLight;
    private static String inkDark;

    private Theme() {}

    /** كنسجّلو Scene جديدة و كنطبّقو عليها الثيم الحالي. */
    public static void register(Scene scene) {
        if (scene != null && !scenes.contains(scene)) {
            scenes.add(scene);
            String url = Theme.class.getResource(STYLESHEET).toExternalForm();
            if (!scene.getStylesheets().contains(url)) {
                scene.getStylesheets().add(url);
            }
            apply(scene);
        }
    }

    /**
     * كيطبّق الثيم الحالي على أي Scene خارجية (بلا تسجيلها فـ `scenes`).
     * مستعملة باش Alert/Dialog يبانو بنفس الثيم الحالي: عندهم Scene
     * ديالهم وحدها (Stage منفصل)، فما كيرثوش الـ stylesheet/كلاس "dark"
     * ديال النافذة الأم تلقائياً.
     *
     * ملاحظة مهمة: هادي عمداً ماشي register() — register() كيزيد
     * الـ Scene فـ `scenes` (لائحة قوية، bلا WeakHashMap)، و كل
     * Alert/Dialog كيصاوب Scene جديدة فكل مرة كيتبان، فلو استعملنا
     * register() هنا كان غادي يبقى كل Scene ديال كل Alert اتبان من قبل
     * محتفظ بيه فالميموري طول عمر التطبيق (memory leak). applyTo() كتطبّق
     * الثيم مرة وحدة بلا ما تربط أي مرجع دائم.
     */
    public static void applyTo(Scene scene) {
        if (scene == null || scene.getRoot() == null) return;
        String url = Theme.class.getResource(STYLESHEET).toExternalForm();
        if (!scene.getStylesheets().contains(url)) {
            scene.getStylesheets().add(url);
        }
        apply(scene);
    }

    /**
     * كنسجّلو MenuBar باش الثيم يتبعها. بالإضافة للـ Skin reset فـ
     * toggle()، كنفرضو هنا لون النص مباشرة على كل MenuItem (أنظر
     * applyMenuItemColors) — لأن التجربة بيّنت أن الاعتماد غير على
     * CSS cascade عبر حدود popup Scene ماكانش كافي/موثوق 100% فهاد
     * الحالة (النص كان كيبقى غير مرئي فالوضع النهاري حتى بعد إعادة
     * بناء الـ Skin). تعيين -fx-text-fill مباشرة على الـ MenuItem
     * (inline style) آلية مختلفة تماما: كتفرض القيمة فوراً بلا ما
     * تعتمد على أي CSS variable resolution عبر Scene منفصلة، ولا على
     * أي cache داخلي للـ Label — الـ Skin ديال MenuItem مبني باش
     * يراقب التغيير فـ style ديالو بالذات ويعكسو فوراً.
     */
    public static void bindMenuBar(MenuBar bar) {
        if (bar == null) return;
        menuBars.add(bar);
        applyMenuItemColors(bar);
    }

    /** كنمشيو على كل MenuItem (بما فيها الفرعية) ونفرضو لون النص الحالي. */
    private static void applyMenuItemColors(MenuBar bar) {
        String color = inkHex();
        for (javafx.scene.control.Menu menu : bar.getMenus()) {
            applyMenuItemColors(menu.getItems(), color);
        }
    }

    /**
     * Couleur du texte des MenuItem (mode courant), résolue depuis la feuille
     * de style elle-même (token -ink de .root / .root.dark) au lieu d'une
     * constante hexadécimale dupliquée dans le code. Mécanisme : une "sonde"
     * Label dans une Scene jetable (jamais montrée, jamais attachée à une
     * fenêtre) charge styles.css et résout .theme-ink-probe { -fx-text-fill: -ink; }.
     * Aucune interaction avec les skins/caches JavaFX : la sonde vit en dehors
     * du graphe réel, on se contente de LIRE la couleur que la feuille de style
     * définit pour le mode courant.
     */
    private static String inkHex() {
        if (dark ? inkDark == null : inkLight == null) {
            String resolved = resolveInkFromStylesheet(dark);
            if (dark) inkDark = resolved; else inkLight = resolved;
        }
        return dark ? inkDark : inkLight;
    }

    private static String resolveInkFromStylesheet(boolean darkMode) {
        try {
            Label probe = new Label();
            probe.getStyleClass().addAll("root", "theme-ink-probe");
            if (darkMode) probe.getStyleClass().add(DARK_CLASS);
            Scene scene = new Scene(probe);
            String url = Theme.class.getResource(STYLESHEET).toExternalForm();
            scene.getStylesheets().add(url);
            probe.applyCss();
            if (probe.getTextFill() instanceof Color c) {
                return String.format("#%02x%02x%02x",
                        Math.round(c.getRed() * 255),
                        Math.round(c.getGreen() * 255),
                        Math.round(c.getBlue() * 255));
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Résolution du token -ink impossible, valeur de secours utilisée", e);
        }
        // Filet de sécurité : ne doit survenir que si la feuille de style est absente.
        return darkMode ? "#e5e7eb" : "#0f172a";
    }

    private static void applyMenuItemColors(List<javafx.scene.control.MenuItem> items, String color) {
        for (javafx.scene.control.MenuItem item : items) {
            if (item instanceof javafx.scene.control.Menu sub) {
                applyMenuItemColors(sub.getItems(), color);
            } else if (!(item instanceof javafx.scene.control.SeparatorMenuItem)) {
                String base = item.getStyle() == null ? "" : item.getStyle().replaceAll("-fx-text-fill:[^;]+;?", "");
                item.setStyle(base + "-fx-text-fill: " + color + ";");
            }
        }
    }

    /**
     * ComboBox / DatePicker: الـ popup ديالهم (لائحة الاختيارات، تقويم
     * التاريخ) عادة كيتبنى محتواه (ListView cells) من جديد فكل مرة
     * كيتفتح — عكس MenuBar، ماشي مخبأ بنفس الطريقة — لكن الـ Scene
     * ديال الـ popup بروحها بقات محتاجة كلاس "dark" + الـ stylesheet،
     * لأنها Scene منفصلة عن جذر الـ Scene الرئيسية.
     */
    public static void bindPopup(ComboBoxBase<?> control) {
        if (control == null) return;
        control.showingProperty().addListener((obs, wasShowing, isShowing) -> {
            if (isShowing) {
                Platform.runLater(() -> applyToPopupOwnedBy(control));
            }
        });
    }

    /** كنبدّلو بين الليلي و النهاري على جميع النوافذ. */
    public static void toggle() {
        dark = !dark;
        scenes.removeIf(s -> s.getWindow() == null);
        for (Scene s : scenes) apply(s);
        // ملاحظة: هنا ما كنهدموش الـ Skin ديال MenuBar (setSkin(null) +
        // new MenuBarSkin) بحال ما كان من قبل. السبب: كل Skin كيسجّل
        // listener على menu.showingProperty ديال كل Menu (داخل rebuildUI
        // ديال MenuBarSkin)، و dispose ديال MenuBarSkin ما كيزيلهومش.
        // الـ Skin القديم كيبقى "زومبي" معلّق على الـ Menus، وأول مرة
        // كيتفتح Menu من بعد كتنفجر NPE فـ MenuBarSkin.menuModeStart
        // (getSkinnable() رجع null). كفاية دابا أن المحتوى كيعاود
        // يتصاوب من جديد فأول فتح بعد التبديل (الـ Popup كيورث الستايل
        // ديال Scene الأم)، فنعاودو غير نطبقو الألوان المباشرة على
        // MenuItems + كلاس "dark" على الجذور — بدون ما نلمسو الـ Skin.
        if (!menuBars.isEmpty()) {
            List<MenuBar> snapshot = new ArrayList<>(menuBars);
            for (MenuBar bar : snapshot) applyMenuItemColors(bar);
        }
    }

    public static boolean isDark() { return dark; }

    private static void applyToPopupOwnedBy(javafx.scene.Node owner) {
        Window ownerWindow = owner.getScene() != null ? owner.getScene().getWindow() : null;
        if (ownerWindow == null) return;
        String url = Theme.class.getResource(STYLESHEET).toExternalForm();
        for (Window w : Window.getWindows()) {
            if (w instanceof PopupWindow pw && pw.getOwnerWindow() == ownerWindow) {
                Scene s = pw.getScene();
                if (s == null || s.getRoot() == null) continue;
                if (!s.getStylesheets().contains(url)) {
                    s.getStylesheets().add(url);
                }
                if (dark) {
                    if (!s.getRoot().getStyleClass().contains(DARK_CLASS)) {
                        s.getRoot().getStyleClass().add(DARK_CLASS);
                    }
                } else {
                    s.getRoot().getStyleClass().remove(DARK_CLASS);
                }
                s.getRoot().applyCss();
                s.getRoot().layout();
            }
        }
    }

    private static void apply(Scene scene) {
        Parent root = scene.getRoot();
        if (root == null) return;
        if (dark) {
            if (!root.getStyleClass().contains(DARK_CLASS)) {
                root.getStyleClass().add(DARK_CLASS);
            }
        } else {
            root.getStyleClass().remove(DARK_CLASS);
        }
        root.applyCss();
        root.layout();
    }
}
