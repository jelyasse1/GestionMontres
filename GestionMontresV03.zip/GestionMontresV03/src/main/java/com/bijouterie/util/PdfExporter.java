package com.bijouterie.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 *  PdfExporter — تصدير لـ PDF بدون أي مكتبة خارجية
 * ============================================================
 *  PDF هو فورما نصية. هنا كنبنيو ملف PDF بسيط (نص + جدول) يدوياً:
 *    • عنوان فالأعلى
 *    • صف الرؤوس + صفوف البيانات (الأعمدة مفصولة)
 *    • ترقيم تلقائي للصفحات (pagination) ملي تكثر الصفوف
 *  كنستعملو الخط القياسي Helvetica (WinAnsi) — كيدعم الحروف الفرنسية (é è à ç…).
 */
public final class PdfExporter {

    private static final Charset CP1252 = Charset.forName("windows-1252");
    private static final double PAGE_W = 595, PAGE_H = 842;   // A4
    private static final double TOP = 800, BOTTOM = 60, LEFT = 50;

    private PdfExporter() {}

    public static void export(File file, String title,
                              String[] headers, List<String[]> rows) throws IOException {
        // ---- حساب عرض كل عمود (بالأحرف) ----
        int cols = headers.length;
        int[] w = new int[cols];
        for (int i = 0; i < cols; i++) w[i] = headers[i].length();
        for (String[] r : rows)
            for (int i = 0; i < cols && i < r.length; i++)
                w[i] = Math.max(w[i], r[i] == null ? 0 : r[i].length());
        for (int i = 0; i < cols; i++) w[i] = Math.min(w[i] + 2, 30);

        String headerLine = joinRow(headers, w);
        String sep = "-".repeat(Math.min(headerLine.length(), 110));

        // ---- توزيع الأسطر على الصفحات ----
        List<String> pageStreams = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        double y = TOP;
        cur.append(line(LEFT, y, 16, title)); y -= 28;
        cur.append(line(LEFT, y, 10, headerLine)); y -= 14;
        cur.append(line(LEFT, y, 10, sep)); y -= 16;
        for (String[] r : rows) {
            if (y < BOTTOM) {
                pageStreams.add(cur.toString());
                cur = new StringBuilder();
                y = TOP;
                cur.append(line(LEFT, y, 10, headerLine)); y -= 14;
                cur.append(line(LEFT, y, 10, sep)); y -= 16;
            }
            cur.append(line(LEFT, y, 10, joinRow(r, w))); y -= 15;
        }
        // تذييل: عدد الصفوف
        if (y < BOTTOM) { pageStreams.add(cur.toString()); cur = new StringBuilder(); y = TOP; }
        cur.append(line(LEFT, Math.max(y - 10, BOTTOM), 9, "Total: " + rows.size() + " ligne(s)"));
        pageStreams.add(cur.toString());

        Files.write(file.toPath(), buildPdf(pageStreams));
    }

    /** كيبني بنية الـ PDF كاملة (objects + xref). */
    private static byte[] buildPdf(List<String> pageStreams) throws IOException {
        int nPages = pageStreams.size();
        // ترقيم الكائنات: 1=Catalog, 2=Pages, 3=Font, ثم لكل صفحة: page + content
        int totalObjs = 3 + nPages * 2;
        List<Integer> offsets = new ArrayList<>();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        writeBytes(out, "%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n");

        // 1: Catalog
        offsets.add(out.size());
        writeBytes(out, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

        // 2: Pages
        StringBuilder kids = new StringBuilder();
        for (int i = 0; i < nPages; i++) kids.append(4 + 2 * i).append(" 0 R ");
        offsets.add(out.size());
        writeBytes(out, "2 0 obj\n<< /Type /Pages /Kids [" + kids.toString().trim()
                + "] /Count " + nPages + " >>\nendobj\n");

        // 3: Font
        offsets.add(out.size());
        writeBytes(out, "3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica "
                + "/Encoding /WinAnsiEncoding >>\nendobj\n");

        // الصفحات
        for (int i = 0; i < nPages; i++) {
            int pageObj = 4 + 2 * i;
            int contentObj = 5 + 2 * i;

            offsets.add(out.size());
            writeBytes(out, pageObj + " 0 obj\n<< /Type /Page /Parent 2 0 R "
                    + "/MediaBox [0 0 " + (int) PAGE_W + " " + (int) PAGE_H + "] "
                    + "/Resources << /Font << /F1 3 0 R >> >> "
                    + "/Contents " + contentObj + " 0 R >>\nendobj\n");

            byte[] streamBytes = pageStreams.get(i).getBytes(CP1252);
            offsets.add(out.size());
            writeBytes(out, contentObj + " 0 obj\n<< /Length " + streamBytes.length + " >>\nstream\n");
            out.write(streamBytes);
            writeBytes(out, "\nendstream\nendobj\n");
        }

        // xref
        int xrefPos = out.size();
        writeBytes(out, "xref\n0 " + (totalObjs + 1) + "\n");
        writeBytes(out, "0000000000 65535 f \n");
        for (int off : offsets) writeBytes(out, String.format("%010d 00000 n \n", off));

        writeBytes(out, "trailer\n<< /Size " + (totalObjs + 1) + " /Root 1 0 R >>\n");
        writeBytes(out, "startxref\n" + xrefPos + "\n%%EOF");
        return out.toByteArray();
    }

    private static void writeBytes(ByteArrayOutputStream out, String s) throws IOException {
        out.write(s.getBytes(CP1252));
    }

    /** سطر نص واحد فالـ content stream. */
    private static String line(double x, double y, int size, String text) {
        return "BT /F1 " + size + " Tf " + (int) x + " " + (int) y + " Td ("
                + esc(text) + ") Tj ET\n";
    }

    private static String joinRow(String[] cells, int[] w) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < w.length; i++) {
            String v = (i < cells.length && cells[i] != null) ? cells[i] : "";
            if (v.length() > w[i]) v = v.substring(0, w[i] - 1) + "…";
            sb.append(pad(v, w[i]));
        }
        return sb.toString();
    }

    private static String pad(String s, int n) {
        if (s.length() >= n) return s;
        return s + " ".repeat(n - s.length());
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
                .replace("\r", "").replace("\n", " ");
    }
}
