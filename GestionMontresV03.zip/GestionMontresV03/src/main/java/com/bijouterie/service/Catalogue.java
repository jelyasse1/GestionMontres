package com.bijouterie.service;

import com.bijouterie.dao.MontreDAO;
import com.bijouterie.model.Accessoire;
import com.bijouterie.model.Montre;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Catalogue — خدمة التطبيق (Application Service).
 * كتخزّن لائحة الساعات (ObservableList) و كتمرّر العمليات للـ DAO (MySQL).
 *  • refresh: كيقرا من قاعدة البيانات.
 *  • ajouter/modifier/supprimer: كيحفظو فـ MySQL و كيحدّثو اللائحة.
 *  • dupliquer: نسخ عميق (copie profonde) + حفظ كساعة جديدة.
 *  • getStats / countByTypeMecanisme / prixParMontre: قواعد العمل (agrégation)
 *    لي كتخدم بيها الواجهة، بعيداً عن الـ Controllers.
 *  • validerMontre: قواعد العمل (invariants du domaine) — ممركزة هنا،
 *    ولا ليها أي نسخة "فقط فالواجهة".
 *
 *  (Dependency Injection) — الـ DAO كيتحقن عبر الـ constructor من عند
 *  Composition Root (MainApp). ما بقاش Singleton مخفي.
 */
public class Catalogue {

    private static final Logger LOG = Logger.getLogger(Catalogue.class.getName());

    /** Résultat d'agrégation pour les cartes KPI de l'interface. */
    public record CatalogueStats(int nbMontres, double valeurTotale, double prixMoyen) {}

    /** Suffixe ajouté au modèle lors d'une copie profonde. */
    private static final String SUFFIXE_COPIE = " (copie)";

    private final MontreDAO dao;
    private final ObservableList<Montre> montres = FXCollections.observableArrayList();
    private boolean refreshFailed = false;

    public Catalogue(MontreDAO dao) {
        this.dao = dao;
        // التحميل الأول فور الإنشاء: الواجهة تعرض البيانات فور ظهورها دون خطوة إضافية.
        refresh();
    }

    public ObservableList<Montre> getMontres() { return montres; }

    /** صحيح إذا تعذّرت قراءة آخر refresh() (قاعدة البيانات غير متاحة). */
    public boolean isRefreshFailed() { return refreshFailed; }

    /**
     * يعيد قراءة الساعات من MySQL.
     * لماذا نحبس الخطأ بدل تركه ينهار التطبيق؟ لأن قاعدة البيانات (XAMPP) قد
     * تكون مطفأة: الفائدة = «تدهور لطيف» — يبقى الكتالوج فارغاً مع لافتة تحذير
     * في الواجهة، ويُعاد الاتصال لاحقاً بزر «Recharger».
     */
    public void refresh() {
        try {
            montres.setAll(dao.findAll());
            refreshFailed = false;
        } catch (Exception e) {
            refreshFailed = true;
            // Dégradation gracieuse (XAMPP éteint) : le catalogue reste vide, mais
            // l'erreur est journalisée (contextualisée) et exposée à l'UI via isRefreshFailed().
            LOG.log(Level.WARNING, "Échec du chargement du catalogue depuis la base de données", e);
        }
    }

    /** CREATE: حفظ ساعة جديدة (التحقق من قواعد العمل قبل الكتابة). */
    public void ajouter(Montre m) {
        validerMontre(m);     // قواعد العمل قبل الحفظ — لا ساعة غير صالحة تدخل DB
        dao.save(m);          // id كيتعمّر هنا
        montres.add(m);
    }

    /** UPDATE: حفظ تعديلات ساعة موجودة (remplacement en place pour garder l'identité). */
    public void modifier(Montre m) {
        validerMontre(m);
        dao.save(m);          // id != 0 => UPDATE
        for (int i = 0; i < montres.size(); i++) {
            if (montres.get(i).getId() == m.getId()) { montres.set(i, m); return; }
        }
        // Sécurité : si l'élément n'est plus en mémoire (ex. refresh), on le ré-ajoute.
        montres.add(m);
    }

    /** DELETE. */
    public void supprimer(Montre m) {
        dao.delete(m);
        montres.remove(m);
    }

    /**
     * نسخ عميق (copie profonde) + حفظ كساعة مستقلة جديدة.
     * لماذا نضيف « (copie)»؟ لتمييز النسخة في القائمة؛ و«لماذا الاقتطاع؟» لأن
     * عمود DB يحصر الموديل في 120 حرفاً، فنحافظ على اللاحقة دون تجاوز الحد.
     */
    public Montre dupliquer(Montre m) {
        Montre c = m.copie();              // نسخة عميقة (id=0)
        // La colonne DB limite le modèle à 120 caractères : on garde le suffixe "(copie)".
        String nom = m.getModele() + SUFFIXE_COPIE;
        if (nom.length() > Montre.MODELE_MAX_LENGTH)
            nom = m.getModele().substring(0, Montre.MODELE_MAX_LENGTH - SUFFIXE_COPIE.length()) + SUFFIXE_COPIE;
        c.setModele(nom);
        validerMontre(c);
        dao.save(c);                       // INSERT => id جديد
        montres.add(c);
        return c;
    }

    /**
     * قواعد العمل المركزية (ثوابت النطاق).
     * لماذا هنا وليس في الواجهة فقط؟ لتكون مرجعاً وحيداً (مصدر واحد للحقيقة):
     *   • تستدعيها الواجهة قبل الحفظ،
     *   • وتستدعيها الاختبارات مباشرة للتحقق منها،
     * فلا يمكن أن يتحايل أحد على القاعدة عبر مسار آخر.
     * خطأ IllegalArgumentException يصف القاعدة المخالفة.
     */
    public void validerMontre(Montre m) {
        if (m == null) throw new IllegalArgumentException("La montre est obligatoire.");
        if (m.getModele() == null || m.getModele().trim().isEmpty())
            throw new IllegalArgumentException("Le modèle est obligatoire.");
        if (m.getModele().length() > Montre.MODELE_MAX_LENGTH)
            throw new IllegalArgumentException("Le modèle ne peut pas dépasser " + Montre.MODELE_MAX_LENGTH + " caractères.");
        if (m.getValeurDeBase() < 0 || !Double.isFinite(m.getValeurDeBase()))
            throw new IllegalArgumentException("La valeur de base de la montre doit être un nombre fini non négatif.");
        if (m.getMecanisme() == null)
            throw new IllegalArgumentException("Une montre doit posséder un mécanisme.");
        if (m.getMecanisme().getValeurDeBase() < 0 || !Double.isFinite(m.getMecanisme().getValeurDeBase()))
            throw new IllegalArgumentException("La valeur du mécanisme doit être un nombre fini non négatif.");
        for (Accessoire a : m.getAccessoires()) {
            if (a == null) throw new IllegalArgumentException("Un accessoire ne peut pas être null.");
            if (a.getValeurDeBase() < 0 || !Double.isFinite(a.getValeurDeBase()))
                throw new IllegalArgumentException("Le prix de l'accessoire « " + a.getNom() + " » doit être un nombre fini non négatif.");
        }
    }

    // ===================== قواعد العمل / التجميع (Business rules) =====================
    // هذه الحسابات هي منطق أعمال: الواجهة (Controller) تستهلك النتائج فقط.

    /** KPI: عدد الساعات، القيمة الإجمالية، الثمن المتوسط. */
    public CatalogueStats getStats() {
        double total = 0;
        for (Montre m : montres) total += m.prix();
        int n = montres.size();
        double moy = n == 0 ? 0 : total / n;
        return new CatalogueStats(n, total, moy);
    }

    /** توزيع الساعات حسب نوع الميكانيزم (مع الحفاظ على ترتيب الإدراج). */
    public Map<String, Integer> countByTypeMecanisme() {
        Map<String, Integer> parType = new LinkedHashMap<>();
        for (Montre m : montres) parType.merge(m.typeMecanisme(), 1, Integer::sum);
        return parType;
    }

    /**
     * Prix total de CHAQUE montre, dans l'ordre d'insertion du catalogue
     * (الثمن الإجمالي لكل ساعة — ترتيب الإدراج = ترتيب الكاطالوگ).
     * Retourne une liste et non une Map indexée par le modèle : « modele »
     * n'est PAS une identité — deux montres peuvent porter le même nom, et
     * une Map perdrait la première (écrasée par la seconde).
     */
    public List<Map.Entry<String, Double>> prixParMontre() {
        List<Map.Entry<String, Double>> parMontre = new ArrayList<>(montres.size());
        for (Montre m : montres)
            parMontre.add(Map.entry(m.getModele(), m.prix()));
        return parMontre;
    }
}
