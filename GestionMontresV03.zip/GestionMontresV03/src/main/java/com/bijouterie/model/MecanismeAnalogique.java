package com.bijouterie.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * MécanismeAnalogique — ميكانيزم بالعقارب. كيطبّق interface Analogique.
 * عندو خاصية إضافية: date (تاريخ معروض) — nullable : null = pas de date.
 */
public class MecanismeAnalogique extends Mecanisme implements Analogique {

    private static final DateTimeFormatter HM = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private LocalDate date; // null = pas de date

    public MecanismeAnalogique(double valeurDeBase, LocalTime heure, LocalDate date) {
        super(valeurDeBase, heure);
        this.date = date;
    }

    /** Surcarge (ép.3) : heure par défaut (12:00) préservée par la chaîne de constructeurs. */
    public MecanismeAnalogique(double valeurDeBase, LocalDate date) {
        this(valeurDeBase, HEURE_PAR_DEFAUT, date);
    }

    /**
     * نسخٌ للميكانيزم التناظري بنوعه الحقيقي.
     * الفائدة: نجعل النسخة تعيد إنتاج الوقت (عبر super(autre)) + التاريخ (date)
     * في سطر واحد؛ ويستفيد منه MecanismeDouble عبر super(autre) أيضاً.
     */
    protected MecanismeAnalogique(MecanismeAnalogique autre) {
        super(autre);
        this.date = autre.date;
    }

    public LocalDate getDate() { return date; }

    /**
     * العرض التناظري — لماذا هو طريقة عامة في interface Analogique؟
     * لنتمكن من التعامل مع أي «ميكانيزم تناظري» (بما فيه Double) بشكل موحّد.
     * الـ date اختياري: null يعني «لا تاريخ معروض».
     */
    @Override
    public String afficheAnalogique() {
        return "🕐 " + getHeure().format(HM) + " (aiguilles)"
                + (date != null ? " 📅 " + date.format(DMY) : "");
    }

    @Override public String typeLabel() { return "Analogique"; }

    /** Ép.3 — partie "cadran" (aiguilles + date éventuelle). */
    @Override protected String toStringCadran() { return afficheAnalogique(); }

    @Override
    public MecanismeAnalogique copie() {
        return new MecanismeAnalogique(this);
    }
}
