package com.bijouterie.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * ============================================================
 *  Montre — الساعة. une montre EST un produit.
 * ============================================================
 *  • تحتوي (encapsule) ميكانيزم واحد.
 *  • مكوّنة من مجموعة (collection hétérogène) ديال الإكسسوارات.
 *  • prix() متعدد الأشكال = القيمة الأساسية + ثمن الميكانيزم + مجموع الإكسسوارات.
 *  • copie() = نسخ عميق (copie profonde): كننسخو الميكانيزم و كل إكسسوار
 *    بنوعو الحقيقي (polymorphique) => النسخة مستقلة تماماً عن الأصل.
 *
 *  Ép.4 — Anti-fuite d'encapsulation:
 *   • le constructeur garde une COPIE du mécanisme reçu (le mécanisme est modifiable) ;
 *   • ajouterAccessoire() ajoute une COPIE de l'accessoire reçu ;
 *   • getAccessoires() renvoie une vue NON modifiable.
 *
 *  Ép.5 — copy constructor : copie profonde polymorphique (mécanisme + accessoires
 *         via copie()); l'id n'est volontairement PAS copié (une copie est une
 *         entité non persistée, id=0 => INSERT).
 *
 *  Ép.6 — le modèle est obligatoire (null ou vide rejeté dès le constructeur).
 *  Ép.7 — equals/hashCode basés sur l'identité d'entité (id) ; un objet non
 *         persisté (id==0) n'est égal à rien d'autre que lui-même (même référence).
 */
public class Montre extends Produit {

    /** Longueur maximale du modèle — miroir de la colonne DB montre.modele (VARCHAR(120)). */
    public static final int MODELE_MAX_LENGTH = 120;

    private String modele;
    private Mecanisme mecanisme;
    private final List<Accessoire> accessoires = new ArrayList<>();
    private int id; // مفتاح قاعدة البيانات (0 = جديدة، مازال ما تحفظاتش)

    public Montre(String modele, double valeurDeBase, Mecanisme mecanisme) {
        super(valeurDeBase);
        validerModele(modele);
        this.modele = modele;
        // نسخ دفاعي (anti-fuite) — لماذا؟ المستدعي قد يغيّر الميكانيزم الخارجي
        // بعد إنشاء الساعة (setHeure...)؛ لو خزّنّا المرجع نفسه لتغيّرت الساعة
        // خلسةً. نسخة خاصة تعزل الساعة عن أي تعديل لاحق خارجها (ép.4).
        this.mecanisme = mecanisme == null ? null : mecanisme.copie();
    }

    /** Copy constructor (ép.5) : copie profonde (défensive) du mécanisme et des accessoires. */
    private Montre(Montre autre) {
        super(autre);
        this.modele = autre.modele;
        this.mecanisme = autre.mecanisme == null ? null : autre.mecanisme.copie();
        for (Accessoire a : autre.accessoires) this.accessoires.add(a.copie());
        // NB : id NON recopié — une copie est une entité non persistée (id=0).
    }

    public int getId()        { return id; }

    public void setId(int id) {
        if (id < 0)
            throw new IllegalArgumentException("L'identifiant d'une montre ne peut pas être négatif : " + id);
        this.id = id;
    }

    public String getModele()                 { return modele; }

    public void setModele(String m) {
        validerModele(m);
        this.modele = m;
    }

    /** Invariant du modèle : obligatoire, non blanc, longueur <= colonne DB (VARCHAR(120)). */
    private static void validerModele(String modele) {
        if (modele == null || modele.trim().isEmpty())
            throw new IllegalArgumentException("Le modèle est obligatoire.");
        if (modele.length() > MODELE_MAX_LENGTH)
            throw new IllegalArgumentException(
                    "Le modèle ne peut pas dépasser " + MODELE_MAX_LENGTH + " caractères.");
    }

    /**
     * Retourne le mécanisme vivant de la montre (référence interne, PAS une copie).
     * Comportement volontaire, différent de getAccessoires() : le mécanisme est
     * un composant unique possédé par la montre — le muter via ce getter
     * (ex. getMecanisme().setHeure(...)) mute l'état de la montre elle-même,
     * ce qui est la sémantique attendue. La protection anti-aliasing vit aux
     * frontières : constructeur (copie défensive du mécanisme reçu) et copie()
     * (copie profonde). Tous les appelants actuels (Service, DAO, contrôleurs)
     * sont en lecture seule.
     */
    public Mecanisme getMecanisme()           { return mecanisme; }

    /**
     * عرض غير قابل للتعديل (vue NON modifiable) — لماذا؟
     * حتى لا يستطيع أي متصل خارجي (واجهة، DAO، مستخدم الكود) إضافة/حذف
     * إكسسوارات من خارج القناة المخصصة (ajouterAccessoire/remplacerAccessoires)
     * حيث تُؤخذ النسخ الدفاعية. الفائدة: تُحفظ encapsulation الساعة دائماً.
     */
    public List<Accessoire> getAccessoires()  { return Collections.unmodifiableList(accessoires); }

    /** Ép.4 — ajoute une COPIE de l'accessoire (pas la référence externe). */
    public void ajouterAccessoire(Accessoire a) {
        if (a != null) accessoires.add(a.copie());
    }

    /** Remplace toute la collection d'accessoires par des copies (utilisé à l'édition). */
    public void remplacerAccessoires(Collection<Accessoire> nouvelles) {
        accessoires.clear();
        for (Accessoire a : nouvelles) accessoires.add(a.copie());
    }

    /** الثمن = القيمة الأساسية + ثمن الميكانيزم + مجموع أثمان الإكسسوارات. */
    @Override
    public double prix() {
        double total = valeurDeBase + (mecanisme != null ? mecanisme.prix() : 0);
        for (Accessoire a : accessoires) total += a.prix();
        return total;
    }

    /**
     * النسخ العميق المتعدد الأشكال (copie profonde polymorphique):
     * كنبنيو montre جديدة عبر الـ copy constructor اللي كيدير النسخ الدفاعية.
     */
    @Override
    public Montre copie() {
        return new Montre(this);
    }

    public String typeMecanisme() {
        return mecanisme != null ? mecanisme.typeLabel() : "—";
    }

    /** عرض متعدد الأشكال للساعة كاملة. */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("⌚ ").append(modele).append("\n");
        sb.append("   Mécanisme : ").append(mecanisme).append("\n");
        if (accessoires.isEmpty()) {
            sb.append("   Accessoires : (aucun)\n");
        } else {
            sb.append("   Accessoires :\n");
            for (Accessoire a : accessoires) sb.append("     • ").append(a).append("\n");
        }
        sb.append(String.format("   PRIX TOTAL : %.2f CHF", prix()));
        return sb.toString();
    }

    // ============ Ép.7 — Identité d'entité (equals / hashCode sur id) ============

    /**
     * Deux montres persistées sont égales si elles ont le même id.
     * Une montre NON persistée (id == 0) n'est égale à aucun autre objet
     * (sauf elle-même, même référence).
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Montre that)) return false;
        if (this.id == 0 || that.id == 0) return false;
        return this.id == that.id;
    }

    @Override
    public int hashCode() {
        // id==0 : jamais égal à quoi que ce soit => hash basé sur l'identité.
        return id == 0 ? System.identityHashCode(this) : Integer.hashCode(id);
    }
}
