package com.bijouterie.model;

/**
 * Accessoire — un accessoire EST un produit (héritage), mais reste une
 * entité abstraite : seules ses sous-classes concrètes (Bracelet, Boîtier,
 * Fermoir, Vitre) peuvent être instanciées.
 *
 * Ép.2 — le nom est fixé par le constructeur (final).
 * Ép.5 — copie() est abstraite : chaque accessoire concret sait se copier
 *        selon son type réel (copie polymorphique).
 */
public abstract class Accessoire extends Produit {

    /** FINAL — le nom ne change pas une fois fixé par le constructeur (ép.2). */
    private final String nom;

    public Accessoire(String nom, double valeurDeBase) {
        super(valeurDeBase);
        this.nom = nom;
    }

    /** Copy constructor (ép.5) : recopie nom et valeur de base. */
    protected Accessoire(Accessoire autre) {
        super(autre);
        this.nom = autre.nom;
    }

    public String getNom() { return nom; }

    /** نسخة عميقة من الإكسسوار — كل كلاس بنت كيعرف كيفاش ينسخ راسو بنوعو. */
    @Override
    public abstract Accessoire copie();

    /**
     * لماذا نستدعي prix() وليس getValeurDeBase()؟ لأن التعاقد (contrat) عام:
     * قد يحسب كلاس بنت لاحقاً ثمناً مختلفاً عن قيمته الأساسية، فيجب أن يظهر
     * «السعر الحقيقي» دائماً. الفائدة: عرض صحيح متعدد الأشكال بلا استثناءات.
     */
    @Override
    public String toString() {
        return String.format("%s (%.2f CHF)", nom, prix());
    }
}
