package com.bijouterie.model;

/**
 * Interface Analogique — سلوك العرض بالعقارب (aiguilles).
 * كل ميكانيزم "analogique" خاصو يعرف يعرض الوقت بالعقارب.
 */
public interface Analogique {
    String afficheAnalogique();
}
