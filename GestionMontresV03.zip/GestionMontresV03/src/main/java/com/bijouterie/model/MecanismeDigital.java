package com.bijouterie.model;

import java.time.LocalTime;

/**
 * MécanismeDigital — ميكانيزم رقمي. كيطبّق interface Digital.
 * عندو خاصية إضافية: heureReveil (وقت المنبّه) — nullable : null = pas de réveil.
 */
public class MecanismeDigital extends Mecanisme implements Digital {

    private LocalTime heureReveil; // null = pas de réveil

    public MecanismeDigital(double valeurDeBase, LocalTime heure, LocalTime heureReveil) {
        super(valeurDeBase, heure);
        this.heureReveil = heureReveil;
    }

    /** Surcarge (ép.3) : heure par défaut (12:00) préservée par la chaîne de constructeurs. */
    public MecanismeDigital(double valeurDeBase, LocalTime heureReveil) {
        this(valeurDeBase, HEURE_PAR_DEFAUT, heureReveil);
    }

    /**
     * نسخٌ للميكانيزم الرقمي بنوعه الحقيقي (الساعة عبر super + وقت المنبّه).
     * الفائدة: النسخ العميق المتعدد الأشكال (copie()) يمرّ عبر هذا البنّاء.
     */
    private MecanismeDigital(MecanismeDigital autre) {
        super(autre);
        this.heureReveil = autre.heureReveil;
    }

    public LocalTime getHeureReveil() { return heureReveil; }

    /**
     * العرض الرقمي — فُوِّض إلى Digital.afficher(...) بدل تكرار الصيغة هنا.
     * لماذا؟ لأن MecanismeDouble يعرض الرقمي أيضاً، وكلاهما لا يستطيع وراثة
     * بعضهما (إرث مفرد) => طريقة ثابتة واحدة تحفظ التنسيق (DRY).
     * الـ heureReveil اختياري: null يعني «لا منبّه».
     */
    @Override
    public String afficheDigital() {
        return Digital.afficher(getHeure(), heureReveil);
    }

    @Override public String typeLabel() { return "Digital"; }

    /** Ép.3 — partie "cadran" (affichage numérique + réveil éventuel). */
    @Override protected String toStringCadran() { return afficheDigital(); }

    @Override
    public MecanismeDigital copie() {
        return new MecanismeDigital(this);
    }
}
