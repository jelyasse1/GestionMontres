package com.bijouterie.model;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * ============================================================
 *  MécanismeDouble — الميكانيزم المزدوج (الدرس الأهم فالـ interfaces)
 * ============================================================
 *  "Un mécanisme double est avant tout un mécanisme ANALOGIQUE auquel
 *   se grefferaient des caractéristiques du mécanisme DIGITAL."
 *
 *  => كيرث من MecanismeAnalogique (باش يستافد من العقارب + التاريخ بلا تكرار)
 *  => و كيطبّق interface Digital (حيت ما يقدرش يرث من جوج كلاسات فـ Java).
 *  => الخاصية "heureReveil" مكرّرة هنا (duplication incontournable كما قال الدرس).
 *  => "Il n'indique qu'une seule heure" => الوقت واحد (مورّث من Mecanisme)،
 *     و عندو جوج طرق باش يتعرض: analogique + digital.
 */
public class MecanismeDouble extends MecanismeAnalogique implements Digital {

    private LocalTime heureReveil; // null = pas de réveil (dupliqué de MecanismeDigital)

    public MecanismeDouble(double valeurDeBase, LocalTime heure, LocalDate date, LocalTime heureReveil) {
        super(valeurDeBase, heure, date);
        this.heureReveil = heureReveil;
    }

    /** Surcarge (ép.3) : heure par défaut (12:00) préservée par la chaîne de constructeurs. */
    public MecanismeDouble(double valeurDeBase, LocalDate date, LocalTime heureReveil) {
        this(valeurDeBase, HEURE_PAR_DEFAUT, date, heureReveil);
    }

    /**
     * نسخٌ للميكانيزم المزدوج بنوعه الحقيقي: الساعة + التاريخ يُنسخان عبر
     * super(autre) (من MecanismeAnalogique)، ثم يُضاف heureReveil هنا.
     * الفائدة: نسخة مستقلة تحافظ على كل بيانات النوعين التناظري والرقمي.
     */
    private MecanismeDouble(MecanismeDouble autre) {
        super(autre);
        this.heureReveil = autre.heureReveil;
    }

    public LocalTime getHeureReveil() { return heureReveil; }

    /** نفس الوقت، معروض رقمياً (تنسيق موحّد عبر Digital.afficher). */
    @Override
    public String afficheDigital() {
        return Digital.afficher(getHeure(), heureReveil);
    }

    @Override public String typeLabel() { return "Double (Analogique + Digital)"; }

    /**
     * Ép.3 — جزء «القرص» : التمثيلان معاً لنفس الوقت الواحد.
     * الفكرة الجوهرية: ساعة واحدة (heure واحدة فقط موروثة) تُعرض بطريقتين،
     * فيرى المستخدم اتساق العقارب مع الأرقام.
     */
    @Override protected String toStringCadran() {
        return afficheAnalogique() + "  |  " + afficheDigital();
    }

    @Override
    public MecanismeDouble copie() {
        return new MecanismeDouble(this);
    }
}
