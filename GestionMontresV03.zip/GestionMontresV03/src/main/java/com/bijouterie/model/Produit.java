package com.bijouterie.model;

/**
 * ============================================================
 *  Produit — الكلاس الأب المجرّد (étude de cas EPFL — Semaine 7)
 * ============================================================
 *  "Un produit est quelque chose que l'on peut vendre, qui a un prix."
 *
 *  • prix() = متعدد الأشكال (polymorphique) ; valeurDeBase = القيمة الأساسية.
 *  • toString() = عرض متعدد الأشكال.
 *  • copie() = نسخ عميق متعدد الأشكال.
 *
 *  Ép.1 : valeurDeBase est FINAL (immuable après construction).
 *  Ép.6 : la valeur de base ne peut pas être négative (invariant vérifié
 *         dès le constructeur).
 *  Ép.5 : copy constructor protected — chaque sous-classe le délègue via super(autre).
 */
public abstract class Produit {

    /**
     * القيمة الأساسية — FINAL (لا تتغير بعد البناء).
     */
    protected final double valeurDeBase;

    protected Produit(double valeurDeBase) {
        // لماذا هذا الفحص هنا تحديداً؟ لأنه في البنّاء المركزي للكلاس الأب:
        // كل منتج (ساعة/ميكانيزم/إكسسوار) يمرّ منه => نطبق القاعدة مرة واحدة
        // فيستفيد الجميع منها ولا يمكن لأي كلاس بنت تجاوزها (دفاعٌ مركزي واحد).
        // الفائدة: رفض القيم السالبة وNaN / ±Infinity مبكراً (مثلاً «1e309» من الواجهة)
        // بدل أن تظهر أخطاء غامضة لاحقاً في الحسابات أو قاعدة البيانات.
        if (valeurDeBase < 0)
            throw new IllegalArgumentException(
                    "La valeur de base d'un produit ne peut pas être négative : " + valeurDeBase);
        if (!Double.isFinite(valeurDeBase))
            throw new IllegalArgumentException(
                    "La valeur de base d'un produit doit être un nombre fini : " + valeurDeBase);
        this.valeurDeBase = valeurDeBase;
    }

    /**
     * نسخٌ عبر super(autre) — لماذا التفويض إلى this(valeurDeBase)؟
     * لنعيد تمرير القيمة عبر نفس الفحص (Invariant) بدل نسخ الحقل مباشرة،
     * فلا يمكن إنتاج منتج بلا قيمة صالحة حتى عبر طريق النسخ.
     */
    protected Produit(Produit autre) {
        this(autre.valeurDeBase);
    }

    public double getValeurDeBase()        { return valeurDeBase; }

    /**
     * الثمن — لماذا نجعله قابلاً لإعادة التعريف؟ لأن «ثمن الساعة» = القاعدة +
     * ثمن الميكانيزم + أثمان الإكسسوارات، ولا نعرفه إلا عند النوع الملموس.
     * الفائدة: التعامل مع كل المنتجات عبر متغير من نوع Produit (polymorphisme).
     */
    public double prix() {
        return valeurDeBase;
    }

    /** النسخ العميق المتعدد الأشكال — كل كلاس بنت كترجّع نسخة من نوعها الحقيقي. */
    public abstract Produit copie();

    /**
     * لماذا نعرض prix() ولا valeurDeBase هنا؟ لأنه في حالة Montre السعر المحسوب
     * يختلف عن القيمة الأساسية؛ فلو عرضنا الحقل لظهر سعرٌ خاطئ لكل منتج مركّب.
     * الفائدة: toString() يبقى صحيحاً تلقائياً مهما غيّرت السعر.
     */
    @Override
    public String toString() {
        return String.format("Produit (%.2f CHF)", prix());
    }
}
