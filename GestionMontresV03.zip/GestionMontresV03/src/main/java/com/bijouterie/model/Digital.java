package com.bijouterie.model;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Interface Digital — سلوك العرض الرقمي (chiffres).
 * كل ميكانيزم "digital" خاصو يعرف يعرض الوقت بالأرقام.
 *
 * afficher() : format d'affichage numérique PARTAGÉ entre MecanismeDigital
 * et MecanismeDouble (qui ne peut pas hériter de MecanismeDigital — héritage
 * simple). Évite la duplication de la logique d'affichage (DRY).
 */
public interface Digital {

    DateTimeFormatter HMS = DateTimeFormatter.ofPattern("HH:mm:ss");

    /** Affichage numérique du temps, suivi du réveil éventuel (null = pas de réveil). */
    static String afficher(LocalTime heure, LocalTime reveil) {
        return "🔢 " + heure.format(HMS)
                + (reveil != null ? " ⏰ " + reveil.format(HMS) : "");
    }

    String afficheDigital();
}
