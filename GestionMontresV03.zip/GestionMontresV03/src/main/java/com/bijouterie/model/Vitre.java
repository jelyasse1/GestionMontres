package com.bijouterie.model;

/**
 * Vitre — زجاج الساعة (Accessoire ملموس).
 *
 * الهدف: نمذجة «الزجاج» كمنتج مستقل بثمنه يُضاف إلى الساعة.
 * الفائدة: بفضل الوراثة من Produit يشارك في Montre.prix() ويُنسخ بنوعه
 *          الحقيقي عند النسخ العميق، دون رمز خاص به في الطبقات العليا.
 * لماذا NOM ثابت؟ الاسم مرتبط بالنوع (لا يُدخله المستخدم)؛ الثابت الوحيد
 *          يُستعمل في الواجهة وDAO — مصدر واحد للحقيقة يمنع التناقض.
 */
public class Vitre extends Accessoire {
    /** اسم العرض — ثابت لأن النوع يحدّد الاسم (مصدر وحيد للحقيقة). */
    public static final String NOM = "Vitre";

    public Vitre(double valeurDeBase) { super(NOM, valeurDeBase); }

    /** نسخ عميق: يعيد بناء نفس القيم عبر super(autre). */
    private Vitre(Vitre autre) { super(autre); }

    /** نسخ متعدد الأشكال يحافظ على النوع الحقيقي (Vitre) عند النسخ العميق. */
    @Override public Vitre copie() { return new Vitre(this); }
}
