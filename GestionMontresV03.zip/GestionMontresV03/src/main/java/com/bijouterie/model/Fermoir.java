package com.bijouterie.model;

/**
 * Fermoir — إبزيم/مشبك الساعة (Accessoire ملموس).
 *
 * الهدف: نمذجة «الإبزيم» كمنتج مستقل بثمنه يُضاف إلى الساعة.
 * الفائدة: الوراثة من Accessoire/Produit تمنحه prix() ويسمح بتعدّد الأشكال
 *          في الحساب والعرض والنسخ العميق دون معاملة خاصة لكل نوع.
 * لماذا NOM ثابت؟ اسم النوع مقرَّر سلفاً؛ الثابت الوحيد يُستعمل في الواجهة
 *          وDAO فلا يتشتّت النص بين الطبقات.
 */
public class Fermoir extends Accessoire {
    /** اسم العرض — ثابت لأن النوع يحدّد الاسم (مصدر وحيد للحقيقة). */
    public static final String NOM = "Fermoir";

    public Fermoir(double valeurDeBase) { super(NOM, valeurDeBase); }

    /** نسخ عميق: يعيد بناء نفس القيم عبر super(autre). */
    private Fermoir(Fermoir autre) { super(autre); }

    /** نسخ متعدد الأشكال يحافظ على النوع الحقيقي (Fermoir) عند النسخ العميق. */
    @Override public Fermoir copie() { return new Fermoir(this); }
}
