package com.bijouterie.model;

/**
 * Boîtier — علبة الساعة (Accessoire ملموس).
 *
 * الهدف: نمذجة «العلبة» كمنتج مستقل بثمنه داخل الساعة.
 * الفائدة: كونه Produit يسمح باحتساب سعره ضمن Montre.prix() بشكل متعدد
 *          الأشكال، وبنسخه بنوعه الحقيقي عند النسخ العميق.
 * لماذا NOM ثابت؟ الاسم مرتبط بالنوع ولا يُدخله المستخدم؛ مشاركة الثابت
 *          بين الواجهة وDAO تجنّب تكرار النصوص (مصدر وحيد للحقيقة).
 */
public class Boitier extends Accessoire {
    /** اسم العرض — ثابت لأن النوع يحدّد الاسم (مصدر وحيد للحقيقة). */
    public static final String NOM = "Boîtier";

    public Boitier(double valeurDeBase) { super(NOM, valeurDeBase); }

    /** نسخ عميق: يعيد بناء نفس القيم عبر super(autre) (انظر Bracelet.copie). */
    private Boitier(Boitier autre) { super(autre); }

    /** نسخ متعدد الأشكال يحافظ على النوع الحقيقي (Boitier) عند النسخ العميق. */
    @Override public Boitier copie() { return new Boitier(this); }
}
