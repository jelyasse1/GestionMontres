package com.bijouterie.model;

/**
 * Bracelet — سوار الساعة (Accessoire ملموس).
 *
 * الهدف: نمذجة «السوار» كمنتج مستقل بثمنه داخل الساعة.
 * الفائدة: بما أنه Produit، يرث prix()/valeurDeBase ويمكن التعامل معه
 *          بشكل موحّد (polymorphisme) في الساعة والواجهة وقاعدة البيانات.
 * لماذا NOM ثابت؟ لأن اسم النوع مقرَّر مسبقاً، ولا يدخله المستخدم؛
 *          استعمال نفس الثابت في واجهة التعديل وفي DAO يمنع التكرار
 *          (مصدر واحد للحقيقة).
 */
public class Bracelet extends Accessoire {
    /** اسم العرض — ثابت لأن النوع هو الذي يحدّد الاسم (مصدر وحيد للحقيقة). */
    public static final String NOM = "Bracelet";

    public Bracelet(double valeurDeBase) { super(NOM, valeurDeBase); }

    /**
     * نسخٌ عميق (copy constructor) — الفائدة: يضمن أن النسخة تحمل نفس
     * القيم (الاسم + القيمة الأساسية) عبر super(autre) دون إعادة حساب يدوية.
     */
    private Bracelet(Bracelet autre) { super(autre); }

    /**
     * نسخ متعدد الأشكال يعيد النوع الحقيقي (Bracelet لا Accessoire)؛
     * هذا ما يجعل Montre.copie() تُنتج نسخة مستقلة تحافظ على نوع كل إكسسوار.
     */
    @Override public Bracelet copie() { return new Bracelet(this); }
}
