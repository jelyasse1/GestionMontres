package com.bijouterie.model;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Mécanisme — un mécanisme EST un produit (abstrait).
 * "On supposera qu'il indique une seule heure" => الوقت مخزّن هنا فالميكانيزم،
 * و كيتعرض بطرق مختلفة (analogique / digital) فالكلاسات البنات.
 *
 * Ép.3 — Schéma d'affichage imposé (patron "Template Method"):
 *   • toString() هو FINAL: كيتبع نفس المخطط لكل الميكانيزمات:
 *         type + cadran + prix
 *   • toStringType() : désormais DÉRIVÉ de typeLabel() — chaque sous-classe
 *         ne fournit plus que typeLabel() (source unique de vérité).
 *   • toStringCadran() : كيتعرّف بالافتراضي فالـ Mecanisme (يعرض الوقت)،
 *                        و قابل لإعادة التعريف فالبنات.
 *   • heure par défaut = 12:00 (محفوظ عبر سلسلة البنائين).
 *  Ép.5 : copy constructor protected — chaque sous-classe le délègue via super(autre).
 */
public abstract class Mecanisme extends Produit {

    /**
     * القيمة الافتراضية للساعة (ép.3: 12:00).
     * لماذا public؟ يستعملها أيضاً الـ DAO كقيمة افتراضية في SQL (العمود
     * mec_heure DEFAULT '12:00:00') => مصدر واحد للقيمة يمنع التضارب.
     */
    public static final LocalTime HEURE_PAR_DEFAUT = LocalTime.of(12, 0, 0);

    private static final DateTimeFormatter HMS = DateTimeFormatter.ofPattern("HH:mm:ss");

    private LocalTime heure;

    protected Mecanisme(double valeurDeBase, LocalTime heure) {
        super(valeurDeBase);
        // Invariant obligatoire : toStringCadran() et l'affichage digital
        // formatent l'heure sans garde — un null casserait tout affichage.
        // (Contraire à heureReveil, qui est nullable par conception :
        // "null = pas de réveil".)
        if (heure == null)
            throw new IllegalArgumentException("L'heure d'un mécanisme est obligatoire.");
        this.heure = heure;
    }

    /**
     * نسخ (copy constructor) — الفائدة: البنّاء المحمي يُمكّن كل بنت من النسخ
     * عبر super(autre) فيُحافَظ على الوقت (وبقية القيم) بلا إعادة بناء يدوية.
     */
    protected Mecanisme(Mecanisme autre) {
        super(autre);
        this.heure = autre.heure;
    }

    public LocalTime getHeure()          { return heure; }
    public void setHeure(LocalTime h)    {
        if (h == null)
            throw new IllegalArgumentException("L'heure d'un mécanisme est obligatoire.");
        this.heure = h;
    }

    /**
     * نوع الميكانيزم — تجريدي إلزامي: كل ميكانيزم جديد مضطر للإعلان عن نوعه،
     * فلا يمكن نسيان وصفه في العرض أو في الواجهة. (الاسم يخدم أيضاً الـ UI.)
     */
    public abstract String typeLabel();

    /**
     * Ép.3 — الجزء «النوع» من مخطط العرض، مشتق من typeLabel() :
     * "Mécanisme analogique", "Mécanisme digital",
     * "Mécanisme double (analogique + digital)".
     */
    protected String toStringType() {
        return "Mécanisme " + typeLabel().toLowerCase();
    }

    /** Ép.3 — يعرض «القرص» (الافتراضي: الساعة فقط). محمي وقابل لإعادة التعريف. */
    protected String toStringCadran() {
        return "heure " + heure.format(HMS);
    }

    /**
     * لماذا FINAL؟ لنضمن أن كل الميكانيزمات (الآن والمستقبل) تُعرض بنفس المخطط
     * «النوع — القرص — السعر». لو تُرك قابلاً لإعادة التعريف لاستطاع أحد البنات
     * كسر اتساق العرض في الجدول/لوحة التفاصيل. هذا نمط Template Method:
     * البنات تملأ الأجزاء (typeLabel/toStringCadran) والمخطط ثابت لا يتغير.
     */
    @Override
    public final String toString() {
        return toStringType() + " — " + toStringCadran() + " — "
                + String.format("%.2f CHF", prix());
    }

    /** narrowing (covariant return): نسخة الميكانيزم نوعها Mecanisme. */
    @Override
    public abstract Mecanisme copie();
}
