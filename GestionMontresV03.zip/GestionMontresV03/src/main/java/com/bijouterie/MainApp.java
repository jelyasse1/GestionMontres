package com.bijouterie;

import com.bijouterie.controller.CatalogueController;
import com.bijouterie.controller.MontreEditController;
import com.bijouterie.controller.StatistiquesController;
import com.bijouterie.dao.DAOFactory;
import com.bijouterie.database.HikariDatabaseConnection;
import com.bijouterie.model.Montre;
import com.bijouterie.service.Catalogue;
import com.bijouterie.util.AlertHelper;
import com.bijouterie.util.Theme;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * MainApp — نقطة الدخول (تطبيق JavaFX) لـ "Gestion de Montres / Bijouterie".
 *
 * COMPOSITION ROOT:
 * هنا وحدة منو كيتبناو الاعتمادات (Dependency Injection):
 *   DatabaseConnection (Singleton) ─► MontreDAO (DAOFactory) ─► Catalogue (Service)
 * و كيتحقنو فالـ Controllers عبر controllerFactory ديال كل FXMLLoader.
 * الـ Controllers ما كيبنيوش الاعتمادات ديالهم (لا كيستعملو Singleton مخفي).
 */
public class MainApp extends Application {

    private static final Logger LOG = Logger.getLogger(MainApp.class.getName());

    /** Ressources FXML des vues. */
    private static final String FXML_CATALOGUE     = "/fxml/CatalogueView.fxml";
    private static final String FXML_MONTRE_EDIT   = "/fxml/MontreEditView.fxml";
    private static final String FXML_STATISTIQUES  = "/fxml/StatistiquesView.fxml";

    private Stage primaryStage;

    /**
     * Composition Root: نقطة تجميع الاعتمادات الوحيدة في التطبيق.
     * لماذا هنا؟ لكي تبقى كل الكائنات قابلة للاستبدال في الاختبارات:
     * نستطيع بناء التطبيق بمجرّد تغيير هذه السطر (DAO آخر/قاعدة أخرى)
     * دون تعديل أي Controller. الإنشاء مبكر عند حقل الكلاس ليُحمَّل
     * الكتالوج مرة واحدة فور الإقلاع.
     */
    private final Catalogue catalogue = new Catalogue(DAOFactory.getMontreDAO());

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Gestion de Montres — Étude de cas POO (JavaFX)");
        showCatalogue();
    }

    public void showCatalogue() {
        try {
            FXMLLoader loader = creerChargeur(FXML_CATALOGUE);
            BorderPane root = loader.load();
            Scene scene = new Scene(root);
            Theme.register(scene);
            primaryStage.setScene(scene);
            CatalogueController c = loader.getController();
            c.setMainApp(this);
            primaryStage.show();
        } catch (Exception e) {
            // Erreur contextuelle : journalisée (pile complète) + présentée proprement à l'utilisateur.
            LOG.log(Level.SEVERE, "Impossible de charger CatalogueView.fxml", e);
            AlertHelper.error(primaryStage, "Erreur au démarrage",
                    "Impossible de charger l'interface principale :\n" + e.getMessage());
        }
    }

    /**
     * نافذة إضافة (montre=null) أو تعديل (montre != null).
     * لماذا نافذة واحدة للعمليتين؟ لأن نموذج الإدخال نفسه؛ والمتغير
     * «montre» يحدّد فقط العنوان وملء الحقول مسبقاً (edit).
     * لماذا ترجع Montre (لا void)؟ فيقرّر CatalogueController ما يفعله بعد
     * الحفظ (اختيار الساعة الجديدة/المعدّلة) — أو null عند الإلغاء/الخطأ.
     * النافذة MODAL تمنع التفاعل مع النافذة الأم حتى يُغلق الحوار.
     */
    public Montre showMontreDialog(Montre montre) {
        try {
            FXMLLoader loader = creerChargeur(FXML_MONTRE_EDIT);
            Parent page = loader.load();
            Stage dialog = new Stage();
            dialog.setTitle(montre == null ? "Nouvelle Montre" : "Modifier la Montre");
            dialog.initModality(Modality.WINDOW_MODAL);
            dialog.initOwner(primaryStage);
            Scene scene = new Scene(page);
            Theme.register(scene);
            dialog.setScene(scene);

            MontreEditController c = loader.getController();
            c.setDialogStage(dialog);
            c.setMontre(montre);

            dialog.showAndWait();
            return c.getResultMontre();
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Impossible d'ouvrir la boîte de dialogue d'édition", e);
            AlertHelper.error(primaryStage, "Erreur d'ouverture",
                    "Impossible d'ouvrir la fenêtre de saisie :\n" + e.getMessage());
            return null;
        }
    }

    public void showStatistiques() {
        try {
            FXMLLoader loader = creerChargeur(FXML_STATISTIQUES);
            Parent page = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Statistiques");
            stage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            Theme.register(scene);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Impossible d'ouvrir les statistiques", e);
            AlertHelper.error(primaryStage, "Erreur d'ouverture",
                    "Impossible d'ouvrir les statistiques :\n" + e.getMessage());
        }
    }

    /**
     * Chargeur FXML مع حقن الاعتمادات (يُستعمل لكل المشاهد).
     * لماذا controllerFactory؟ لأن الـ Controllers لدينا ليس لها بنّاء بلا وسائط
     * (تحتاج Catalogue)؛ فهنا نُصنعها يدوياً ونحقن اعتمادها عند الطلب،
     * بدل اعتماد انعكاسٍ خفي أو Singleton.
     */
    private FXMLLoader creerChargeur(String ressource) {
        FXMLLoader loader = new FXMLLoader(MainApp.class.getResource(ressource));
        loader.setControllerFactory(this::createController);
        return loader;
    }

    /**
     * Dependency Injection للـ Controllers:
     * كيصنع كل Controller بحقن الاعتمادات (Service) ديالو.
     * هذا كيخلّي الـ Controllers بلا no-arg constructor و بلا Singleton.
     */
    private Object createController(Class<?> type) {
        if (type == CatalogueController.class)    return new CatalogueController(catalogue);
        if (type == MontreEditController.class)   return new MontreEditController(catalogue);
        if (type == StatistiquesController.class) return new StatistiquesController(catalogue);
        return null; // FXMLLoader كيرجع للتصنيع الافتراضي
    }

    public Stage getPrimaryStage() { return primaryStage; }

    /**
     * إغلاق pool الاتصالات عند خروج التطبيق.
     * لماذا؟ لئلا تبقى اتصالات MySQL مفتوحة بعد انتهاء البرنامج
     * (تسريب موارد يرهق الخادم ويستنزف حد الاتصالات).
     */
    @Override
    public void stop() {
        HikariDatabaseConnection.getInstance().closePool();
    }

    public static void main(String[] args) { launch(args); }
}
