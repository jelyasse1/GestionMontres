package com.bijouterie.database;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * DatabaseConnection — واجهة مجرّدة لمصدر اتصالات JDBC.
 *
 * الهدف: فصل طبقة DAO عن تفاصيل إنشاء الاتصال (من أين يأتي Connection).
 * الفائدة (لماذا واجهة لا كلاساً ملموساً؟):
 *   1) حقنُ الاعتماد (Dependency Injection): الـ DAO يستقبل «مصدر اتصالات»
 *      عبر البنّاء، فيبقى غير مربوط بSingleton ملموس مخفي.
 *   2) قابلية الاختبار: يمكن اختبار DAO على قاعدة حقيقية H2 في الذاكرة
 *      (بدون MySQL) بمجرّد توفير تنفيذ آخر لهذه الواجهة — وهذا ما يفعله
 *      MontreDAOImplTest فعلاً.
 *   3) موحّدية دورة الحياة: من يفتح الاتصال يملك إغلاق المصدر (closePool).
 */
public interface DatabaseConnection {

    /** يرجّع اتصال JDBC جاهزاً (يديره pool الاتصالات — يُعاد إليه عند الإغلاق). */
    Connection getConnection() throws SQLException;

    /** يغلق مصدر الاتصالات (pool). يُستدعى عند خروج التطبيق لإطلاق الموارد. */
    void closePool();
}
