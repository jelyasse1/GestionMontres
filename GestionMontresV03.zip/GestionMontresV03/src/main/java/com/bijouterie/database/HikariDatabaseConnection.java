package com.bijouterie.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * HikariDatabaseConnection — التنفيذ الفعلي لـ {@link DatabaseConnection}
 * فوق HikariCP (pool اتصالات جاهز للـ JDBC). يقرأ إعدادات database.properties.
 *
 * الهدف: تجميع الاتصالات بـ MySQL (إنشاء/إعادة استعمال/إغلاق) بدل فتح
 *        اتصال جديد مع كل طلب — فتح الاتصال عملية مكلفة، والـ pool يخفّضها.
 *
 * لماذا Singleton؟ لأنه مورد عمومي بطبيعته (pool واحد يخدم كل التطبيق)؛
 *        لكنه يُحقن خلف واجهة DatabaseConnection، فيبقى قابلاً للاستبدال
 *        في الاختبارات (H2) ولا يسرّب نفسه إلى الطبقات العليا.
 *
 * الأمان — لا تُكتَب أي كلمة مرور في الكود. ترتيب البحث عن الإعدادات:
 *   1) ./database.properties  (المجلد الحالي للتشغيل) — مكان وضع بيانات
 *      الإنتاج الحقيقية حتى لا تُضمَّن داخل ملف الـ JAR الموزَّع ;
 *   2) /database.properties   (classpath / الموارد) — قيم افتراضية فقط.
 */
public class HikariDatabaseConnection implements DatabaseConnection {

    private static final Logger LOG = Logger.getLogger(HikariDatabaseConnection.class.getName());

    private static HikariDatabaseConnection instance;

    private HikariDataSource dataSource;

    private HikariDatabaseConnection() {
        try {
            Properties props = loadProperties();
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(props.getProperty("db.url"));
            config.setUsername(props.getProperty("db.username", "root"));
            config.setPassword(props.getProperty("db.password", ""));
            config.setMaximumPoolSize(Integer.parseInt(props.getProperty("db.poolSize", "10")));
            config.setPoolName("BijouteriePool");
            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");

            this.dataSource = new HikariDataSource(config);
            LOG.info("Pool MySQL (bijouterie_db) créé avec succès");
        } catch (IllegalStateException e) {
            // مشكل في الإعدادات (غياب URL مثلاً): نخليو dataSource = null
            // والفائدة: التطبيق يبدأ، وكل طلب اتصال سيرجع خطأً واضحاً بدل تعطّل مفاجئ.
            LOG.log(Level.WARNING, "Configuration base de données invalide : {0}", e.getMessage());
            this.dataSource = null;
        } catch (Exception e) {
            // MySQL غير شغّال (XAMPP مطفأ): لا نُسقط التطبيق، بل نحوّل الحالة إلى null
            // وتتعامل معها الواجهة بتدهور لطيف (لافتة «قاعدة البيانات غير متاحة»).
            LOG.log(Level.WARNING, "Problème de connexion à la base de données (XAMPP démarré ?)", e);
            this.dataSource = null;
        }
    }

    /**
     * يبحث عن ملف الإعدادات بالترتيب: خارجي (مجلد التشغيل) أولاً، ثم مورد الـ classpath.
     * الفائدة: ملف الإنتاج الحقيقي لا يُعبّأ في الـ JAR؛ والملف المضمَّن يبقى قالباً افتراضياً.
     */
    private Properties loadProperties() {
        Properties props = new Properties();

        // 1) التجاوز الخارجي (المجلد الحالي) — بيانات حقيقية خارج الـ JAR.
        Path externe = Paths.get("database.properties");
        if (Files.exists(externe)) {
            try (InputStream in = Files.newInputStream(externe)) {
                props.load(in);
                LOG.info("Configuration DB chargée depuis le fichier externe : " + externe.toAbsolutePath());
            } catch (Exception e) {
                throw new IllegalStateException("Impossible de lire le fichier externe database.properties : "
                        + e.getMessage(), e);
            }
        } else {
            // 2) مورد الـ classpath (قيم افتراضية).
            try (InputStream in = getClass().getClassLoader()
                    .getResourceAsStream("database.properties")) {
                if (in != null) props.load(in);
            } catch (Exception e) {
                throw new IllegalStateException("Impossible de lire database.properties : " + e.getMessage(), e);
            }
        }

        String url = props.getProperty("db.url");
        if (url == null || url.trim().isEmpty()) {
            // بداية صريحة وفورية بدل فشل غامض لاحقاً عند أول استعلام.
            throw new IllegalStateException("db.url est absent de database.properties.");
        }
        return props;
    }

    public static synchronized HikariDatabaseConnection getInstance() {
        if (instance == null) instance = new HikariDatabaseConnection();
        return instance;
    }

    @Override
    public Connection getConnection() throws SQLException {
        // اختبار صريح بدل NullPointerException: رسالة واضحة تفيد بأن MySQL غير شغّال.
        if (dataSource == null) throw new SQLException("DataSource non initialisé (XAMPP éteint ?)");
        return dataSource.getConnection();
    }

    @Override
    public void closePool() {
        // يُستدعى في MainApp.stop() لإغلاق كل اتصالات الـ pool عند خروج التطبيق.
        if (dataSource != null) dataSource.close();
    }
}
