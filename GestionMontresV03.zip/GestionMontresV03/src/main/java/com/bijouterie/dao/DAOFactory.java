package com.bijouterie.dao;

import com.bijouterie.dao.impl.MontreDAOImpl;
import com.bijouterie.database.HikariDatabaseConnection;

/**
 * DAOFactory — نمط FACTORY. كيصنع الـ DAO المناسب
 * بلا ما يربط التطبيق مباشرة بالتطبيق الملموس (MontreDAOImpl).
 * كنحقن الـ Connection Pool فـ الـ DAO عند الصنع (Dependency Injection).
 *
 * لماذا Factory بدل new مباشر في كل مكان؟
 * الفائدة: نقطة واحدة تعرف «كيف يُبنى DAO الحقيقي ومع أي مصدر اتصال»؛
 * التطبيق يتعامل مع الواجهة MontreDAO فقط، فلو تغيّر التنفيذ
 * (قاعدة مختلفة، تجمّع آخر) يتبدل هنا فقط دون لمس بقية الكود.
 */
public class DAOFactory {
    public static MontreDAO getMontreDAO() {
        return new MontreDAOImpl(HikariDatabaseConnection.getInstance());
    }
}
