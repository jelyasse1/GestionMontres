package com.bijouterie.dao;

import com.bijouterie.model.Montre;
import java.util.List;

/**
 * MontreDAO — واجهة الوصول للبيانات (نمط DAO).
 * كتفصل منطق التطبيق على تفاصيل SQL.
 */
public interface MontreDAO {
    /** قراءة كل الساعات (مع إكسسواراتها وميكانيزمها بنوعه الحقيقي) مرتبة حسب المعرّف. */
    List<Montre> findAll();
    /** insert إلا كان id==0، أو update إلا كان موجود. كترجّع الساعة مع id محدّث. */
    Montre save(Montre montre);
    /** حذف الساعة من القاعدة (إكسسواراتها تُحذف تلقائياً عبر CASCADE). */
    void delete(Montre montre);
}
