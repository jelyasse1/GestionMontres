package com.bijouterie.dao.impl;

import com.bijouterie.dao.MontreDAO;
import com.bijouterie.database.DatabaseConnection;
import com.bijouterie.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MontreDAOImpl — تطبيق DAO فوق MySQL (JDBC).
 *   • findAll: كيقرا الساعات + كيعاود يبني الميكانيزم بنوعو + كيحمّل الإكسسوارات
 *     (استعلام واحد لكل الساعات، ما بقاش N+1).
 *   • save: insert (id==0) ولا update، + مزامنة الإكسسوارات.
 *   • delete: حذف الساعة (الإكسسوارات كيتمسحو بـ CASCADE).
 *
 *  Transactions (atomicité) :
 *   كل عملية كتابة متعددة البيانات (montre + accessoires) كتدار فـ معاملة وحدة:
 *   autoCommit=false → تنفيذ → commit ; إلا وقع خطأ → rollback.
 *   هاكا ما يبقاش أبداً ساعة مسجّلة بلا إكسسواراتها ولا مع بيانات ناقصة.
 *
 *  Sécurité :
 *   كل الاستعلامات كتستخدم PreparedStatement (معاملات ?) => مفيش SQL Injection.
 *   مفيش أي SQL مبني على مدخلات المستخدم.
 */
public class MontreDAOImpl implements MontreDAO {

    private static final String COLS_MONTRE =
            "id_montre, modele, valeur_base, mec_type, mec_valeur_base, " +
            "mec_heure, mec_date, mec_heure_reveil";

    private static final String COLS_ACCESSOIRE = "id_montre, type, valeur_base";

    /** Valeurs du discriminateur accessoire.type (ENUM SQL — « Boitier » sans accent). */
    private static final String DB_BOITIER   = "Boitier";
    private static final String DB_BRACELET  = "Bracelet";
    private static final String DB_FERMOIR   = "Fermoir";
    private static final String DB_VITRE     = "Vitre";

    /** Valeurs du discriminateur montre.mec_type (ENUM SQL). */
    private static final String DB_MEC_ANALOGIQUE = "ANALOGIQUE";
    private static final String DB_MEC_DIGITAL    = "DIGITAL";
    private static final String DB_MEC_DOUBLE     = "DOUBLE";

    private final DatabaseConnection db;

    /** Injection de la dépendance (source de connexions) via le constructeur. */
    public MontreDAOImpl(DatabaseConnection db) {
        this.db = db;
    }

    @Override
    public List<Montre> findAll() {
        List<Montre> montres = new ArrayList<>();
        String sql = "SELECT " + COLS_MONTRE + " FROM montre ORDER BY id_montre";
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                montres.add(mapMontre(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur findAll montres: " + e.getMessage(), e);
        }
        try {
            chargerAccessoiresBatch(montres);
        } catch (SQLException e) {
            throw new RuntimeException("Erreur chargement accessoires: " + e.getMessage(), e);
        }
        return montres;
    }

    @Override
    public Montre save(Montre m) {
        if (m.getId() == 0) insert(m);
        else                update(m);
        return m;
    }

    // ===================== Transaction (atomicité) =====================

    /** Corps d'une transaction : les requêtes s'exécutent sur la connexion fournie. */
    @FunctionalInterface
    private interface SqlWork {
        void execute(Connection con) throws SQLException;
    }

    /**
     * ينفّذ مجموعة كتابات داخل معاملة واحدة.
     * لماذا؟ لأن حفظ الساعة = تحديث صف montre + مزامنة كل accessoires؛
     * لو فشل أحدهما في منتصف الطريق لبقيت بيانات ناقصة (ساعة بلا إكسسوارات أو
     * العكس). المعاملة تضمن: إمّا أن تُحفظ كل الكتابات، أو لا شيء (rollback).
     */
    private void executeTransaction(String operation, SqlWork work) {
        try (Connection con = db.getConnection()) {
            boolean previousAutoCommit = con.getAutoCommit();
            try {
                con.setAutoCommit(false);
                work.execute(con);
                con.commit();
            } catch (SQLException e) {
                rollback(con, e);
                throw new RuntimeException("Erreur " + operation + " : " + e.getMessage(), e);
            } catch (RuntimeException e) {
                rollback(con, e);
                throw e;
            } finally {
                try { con.setAutoCommit(previousAutoCommit); } catch (SQLException ignored) { /* pool reset */ }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur " + operation + " (connexion) : " + e.getMessage(), e);
        }
    }

    private void rollback(Connection con, Exception cause) {
        try { con.rollback(); } catch (SQLException re) { cause.addSuppressed(re); }
    }

    // ===================== Écritures =====================

    private void insert(Montre m) {
        executeTransaction("insert montre", con -> {
            String sql = "INSERT INTO montre(modele, valeur_base, mec_type, mec_valeur_base, " +
                    "mec_heure, mec_date, mec_heure_reveil) VALUES (?,?,?,?,?,?,?)";
            try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                bindMontre(ps, m);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) m.setId(keys.getInt(1));
                }
            }
            syncAccessoires(con, m);
        });
    }

    private void update(Montre m) {
        executeTransaction("update montre", con -> {
            String sql = "UPDATE montre SET modele=?, valeur_base=?, mec_type=?, mec_valeur_base=?, " +
                    "mec_heure=?, mec_date=?, mec_heure_reveil=? WHERE id_montre=?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                bindMontre(ps, m);
                ps.setInt(8, m.getId());
                ps.executeUpdate();
            }
            syncAccessoires(con, m);
        });
    }

    @Override
    public void delete(Montre m) {
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM montre WHERE id_montre=?")) {
            ps.setInt(1, m.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur delete montre: " + e.getMessage(), e);
        }
    }

    // -------- helpers --------

    private void bindMontre(PreparedStatement ps, Montre m) throws SQLException {
        Mecanisme mec = m.getMecanisme();
        ps.setString(1, m.getModele());
        ps.setDouble(2, m.getValeurDeBase());
        ps.setString(3, mecType(mec));
        ps.setDouble(4, mec != null ? mec.getValeurDeBase() : 0);
        // LocalTime / LocalDate typés (JDBC 4.2) : pas de conversion implicite.
        ps.setObject(5, mec != null ? mec.getHeure() : Mecanisme.HEURE_PAR_DEFAUT);
        ps.setObject(6, dateMecanisme(mec));          // LocalDate ou null
        ps.setObject(7, heureReveilMecanisme(mec));   // LocalTime ou null
    }

    /**
     * يزامن إكسسوارات الساعة: حذف ثم إدراج (batch).
     * لماذا الحذف ثم الإدراج؟ طريقة بسيطة وموثوقة لتعكس «القائمة الكاملة»
     * بعد أي تعديل دون تتبّع كل عنصر على حدة.
     * لماذا batch؟ استعلام واحد محضّر لكل الإكسسوارات بدل استعلام لكل عنصر.
     * يُنفَّذ داخل معاملة save() => الحذف والإدراج معاً (ذرّية).
     */
    private void syncAccessoires(Connection con, Montre m) throws SQLException {
        try (PreparedStatement del = con.prepareStatement("DELETE FROM accessoire WHERE id_montre=?")) {
            del.setInt(1, m.getId());
            del.executeUpdate();
        }
        String sql = "INSERT INTO accessoire(" + COLS_ACCESSOIRE + ") VALUES (?,?,?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (Accessoire a : m.getAccessoires()) {
                ps.setInt(1, m.getId());
                ps.setString(2, accType(a));
                ps.setDouble(3, a.getValeurDeBase());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    /**
     * يحمّل إكسسوارات كل الساعات في استعلام SELECT واحد.
     * لماذا؟ تجنّب مشكلة N+1 (استعلام لكل ساعة) التي تُبطئ التطبيق مع كتالوج كبير:
     * نقرأ كل الصفوف دفعة واحدة ثم نوزّعها على الساعات عبر خريطة id.
     */
    private void chargerAccessoiresBatch(List<Montre> montres) throws SQLException {
        if (montres.isEmpty()) return;
        Map<Integer, Montre> parId = new HashMap<>();
        for (Montre m : montres) parId.put(m.getId(), m);

        String sql = "SELECT " + COLS_ACCESSOIRE + " FROM accessoire ORDER BY id_montre, id_accessoire";
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Montre m = parId.get(rs.getInt("id_montre"));
                if (m != null) {
                    m.ajouterAccessoire(mapAccessoire(rs.getString("type"), rs.getDouble("valeur_base")));
                }
            }
        }
    }

    /**
     * يعيد بناء الكائن من صف النتيجة (ResultSet).
     * لماذا switch على mec_type؟ هذا هو «بقاء تعدد الأشكال بعد الحفظ»:
     * نقرأ المُميّز (discriminateur) ونعيد إنشاء النوع الحقيقي للميكانيزم
     * (Analogique/Digital/Double) — وإلا لتحوّل كل شيء إلى نوع واحد خاطئ.
     */
    private Montre mapMontre(ResultSet rs) throws SQLException {
        String type = rs.getString("mec_type");
        double mv = rs.getDouble("mec_valeur_base");
        LocalTime h = rs.getObject("mec_heure", LocalTime.class);
        LocalDate date = rs.getObject("mec_date", LocalDate.class);
        LocalTime heureReveil = rs.getObject("mec_heure_reveil", LocalTime.class);
        Mecanisme mec;
        if (DB_MEC_DIGITAL.equals(type)) {
            mec = new MecanismeDigital(mv, h, heureReveil);
        } else if (DB_MEC_DOUBLE.equals(type)) {
            mec = new MecanismeDouble(mv, h, date, heureReveil);
        } else if (DB_MEC_ANALOGIQUE.equals(type)) {
            mec = new MecanismeAnalogique(mv, h, date);
        } else {
            // Discriminateur inconnu ou null (donnée corrompue / schéma divergent) :
            // échec explicite — on refuse d'inventer un type de domaine faux.
            // Catalogue.refresh() intercepte l'exception et active le bandeau d'échec.
            throw new IllegalStateException(
                    "mec_type inconnu (« " + type + " ») pour le modele « "
                    + rs.getString("modele") + " » : donnée corrompue ou schéma divergent.");
        }
        Montre m = new Montre(rs.getString("modele"), rs.getDouble("valeur_base"), mec);
        m.setId(rs.getInt("id_montre"));
        return m;
    }

    private Accessoire mapAccessoire(String type, double v) {
        if (DB_BRACELET.equals(type)) return new Bracelet(v);
        if (DB_FERMOIR.equals(type))  return new Fermoir(v);
        if (DB_VITRE.equals(type))    return new Vitre(v);
        if (DB_BOITIER.equals(type))  return new Boitier(v);
        // Discriminateur inconnu ou null (donnée corrompue) : échec explicite —
        // on refuse de transformer l'accessoire en un type de domaine faux.
        throw new IllegalStateException(
                "type d'accessoire inconnu (« " + type + " ») : donnée corrompue ou schéma divergent.");
    }

    private String mecType(Mecanisme mec) {
        if (mec instanceof MecanismeDouble)  return DB_MEC_DOUBLE;
        if (mec instanceof MecanismeDigital) return DB_MEC_DIGITAL;
        return DB_MEC_ANALOGIQUE;
    }

    /** Date affichée (LocalDate) du mécanisme analogique/double, sinon null. */
    private LocalDate dateMecanisme(Mecanisme mec) {
        if (mec instanceof MecanismeAnalogique an) return an.getDate();
        return null;
    }

    /** Heure de réveil (LocalTime) du mécanisme digital/double, sinon null. */
    private LocalTime heureReveilMecanisme(Mecanisme mec) {
        if (mec instanceof MecanismeDouble md)  return md.getHeureReveil();
        if (mec instanceof MecanismeDigital dg) return dg.getHeureReveil();
        return null;
    }

    private String accType(Accessoire a) {
        if (a instanceof Bracelet) return DB_BRACELET;
        if (a instanceof Fermoir)  return DB_FERMOIR;
        if (a instanceof Vitre)    return DB_VITRE;
        return DB_BOITIER;
    }
}
