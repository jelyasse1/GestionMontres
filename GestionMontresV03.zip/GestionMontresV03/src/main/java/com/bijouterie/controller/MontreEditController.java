package com.bijouterie.controller;

import com.bijouterie.model.*;
import com.bijouterie.service.Catalogue;
import com.bijouterie.util.AlertHelper;
import com.bijouterie.util.Theme;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * MontreEditController — نافذة إضافة/تعديل ساعة.
 * كتبني Montre من المدخلات: نوع الميكانيزم، الوقت، الإكسسوارات…
 * و كتعرض الثمن الإجمالي حياً (polymorphisme: prix()).
 *
 * La validation des nombres est STRICTE (pas de 0 silencieux) ;
 * les règles métier (invariants) sont validées par le Service (Catalogue),
 * dont les erreurs sont affichées à l'utilisateur.
 */
public class MontreEditController {

    /** Libellés du sélecteur de type de mécanisme (source unique de vérité de l'UI). */
    private static final String TYPE_ANALOGIQUE = "Analogique";
    private static final String TYPE_DIGITAL    = "Digital";
    private static final String TYPE_DOUBLE     = "Double";

    /** Formats d'heure acceptés/affiches par le formulaire. */
    private static final DateTimeFormatter HMS = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter HM  = DateTimeFormatter.ofPattern("HH:mm");

    @FXML private Label titreLabel;
    @FXML private TextField modeleField;
    @FXML private TextField valeurBaseField;
    @FXML private ComboBox<String> typeCombo;
    @FXML private TextField heureField;
    @FXML private TextField valeurMecField;
    @FXML private CheckBox dateCheck;
    @FXML private DatePicker datePicker;
    @FXML private CheckBox reveilCheck;
    @FXML private TextField timeField;

    @FXML private CheckBox boitierCheck;  @FXML private TextField boitierPrix;
    @FXML private CheckBox braceletCheck; @FXML private TextField braceletPrix;
    @FXML private CheckBox fermoirCheck;  @FXML private TextField fermoirPrix;
    @FXML private CheckBox vitreCheck;    @FXML private TextField vitrePrix;

    @FXML private Label prixLabel;

    private Stage dialogStage;
    private Montre montreToEdit; // null = إضافة
    private Montre resultMontre; // الساعة المحفوظة (لإرجاعها إلى CatalogueController)
    private final Catalogue catalogue;

    /** Injection du service (Application Service) par le Composition Root (MainApp). */
    public MontreEditController(Catalogue catalogue) {
        this.catalogue = catalogue;
    }

    /** La montre ajoutée/modifiée après validation (null si annulé ou en erreur). */
    public Montre getResultMontre() { return resultMontre; }

    @FXML
    private void initialize() {
        typeCombo.getItems().setAll(TYPE_ANALOGIQUE, TYPE_DIGITAL, TYPE_DOUBLE);
        typeCombo.getSelectionModel().select(TYPE_ANALOGIQUE);
        heureField.setText("12:00:00");
        valeurBaseField.setText("100");
        valeurMecField.setText("80");

        // Les options Date / Réveil ne s'appliquent qu'à certains types :
        //   Analogique → date ; Digital → réveil ; Double → les deux.
        typeCombo.valueProperty().addListener((o, a, t) -> appliquerOptionsSelonType());
        appliquerOptionsSelonType();

        // كنربطو الـ popups ديال ComboBox و DatePicker بالثيم الحالي — هادو
        // كيديرو Scene ديالهم بروسهم (منفصلة عن جذر النافذة)، فبلا هاد
        // الربط كيبقاو ديما بألوان الوضع النهاري حتى ولو التطبيق فالليلي.
        Theme.bindPopup(typeCombo);
        Theme.bindPopup(datePicker);

        // La saisie efface la marque d'erreur du champ (validation inline).
        effacerMarqueALaSaisie(modeleField);
        effacerMarqueALaSaisie(valeurBaseField);
        effacerMarqueALaSaisie(heureField);
        effacerMarqueALaSaisie(valeurMecField);
        effacerMarqueALaSaisie(timeField);
        effacerMarqueALaSaisie(boitierPrix);
        effacerMarqueALaSaisie(braceletPrix);
        effacerMarqueALaSaisie(fermoirPrix);
        effacerMarqueALaSaisie(vitrePrix);

        // معاينة الثمن حياً
        lierPrix(valeurBaseField); lierPrix(valeurMecField);
        lierPrix(boitierPrix);     lierPrix(braceletPrix);
        lierPrix(fermoirPrix);     lierPrix(vitrePrix);
        lierPrix(boitierCheck);    lierPrix(braceletCheck);
        lierPrix(fermoirCheck);    lierPrix(vitreCheck);
        lierPrix(dateCheck);       lierPrix(reveilCheck);
        lierPrix(datePicker);
        lierPrix(timeField);
        updatePrix();
    }

    public void setDialogStage(Stage s) { this.dialogStage = s; }

    public void setMontre(Montre m) {
        this.montreToEdit = m;
        if (m == null) { if (titreLabel != null) titreLabel.setText("Nouvelle Montre"); return; }
        if (titreLabel != null) titreLabel.setText("Modifier : " + m.getModele());
        modeleField.setText(m.getModele());
        valeurBaseField.setText(String.valueOf(m.getValeurDeBase()));
        Mecanisme mec = m.getMecanisme();
        valeurMecField.setText(String.valueOf(mec.getValeurDeBase()));
        heureField.setText(mec.getHeure().format(HMS));
        if (mec instanceof MecanismeDouble md) {
            typeCombo.getSelectionModel().select(TYPE_DOUBLE);
            setDateUi(md.getDate());
            setReveilUi(md.getHeureReveil());
        } else if (mec instanceof MecanismeDigital dg) {
            typeCombo.getSelectionModel().select(TYPE_DIGITAL);
            setReveilUi(dg.getHeureReveil());
        } else if (mec instanceof MecanismeAnalogique an) {
            typeCombo.getSelectionModel().select(TYPE_ANALOGIQUE);
            setDateUi(an.getDate());
        }
        for (Accessoire a : m.getAccessoires()) {
            switch (a.getNom()) {
                case Boitier.NOM   -> { boitierCheck.setSelected(true);  boitierPrix.setText(fmt(a.getValeurDeBase())); }
                case Bracelet.NOM  -> { braceletCheck.setSelected(true); braceletPrix.setText(fmt(a.getValeurDeBase())); }
                case Fermoir.NOM   -> { fermoirCheck.setSelected(true);  fermoirPrix.setText(fmt(a.getValeurDeBase())); }
                case Vitre.NOM     -> { vitreCheck.setSelected(true);    vitrePrix.setText(fmt(a.getValeurDeBase())); }
                default -> {}
            }
        }
        updatePrix();
    }

    private String fmt(double d) { return String.valueOf(d); }

    /** Met à jour l'UI (case + picker) pour la date d'un mécanisme analogique/double. */
    private void setDateUi(LocalDate d) {
        dateCheck.setSelected(d != null);
        datePicker.setValue(d);
    }

    /** Met à jour l'UI (case + champ) pour l'heure de réveil d'un mécanisme digital/double. */
    private void setReveilUi(LocalTime t) {
        reveilCheck.setSelected(t != null);
        timeField.setText(t == null ? "" : t.format(HMS));
    }

    /** Valeurs brutes du formulaire (parses uniques, partagées entre l'aperçu et la validation). */
    private record Saisie(String modele, Double valeurBase, LocalTime heure, Double valeurMec,
                          Double boitier, Double bracelet, Double fermoir, Double vitre,
                          LocalDate date, LocalTime reveil) {}

    /**
     * يقرأ كل قيم النموذج في مكان واحد.
     * لماذا؟ حتى يتشارك «معاينة السعر الحية» و«التحقق عند الحفظ» نفس القراءة
     * ونفس قواعد التحليل (مصدر واحد للحقيقة): لا يمكن أن يختلف ما نعاينه
     * عمّا سيُحفظ فعلاً.
     */
    private Saisie lireSaisie() {
        String modele = modeleField.getText() == null ? "" : modeleField.getText().trim();
        LocalDate date = dateCheck.isSelected() ? datePicker.getValue() : null;
        LocalTime reveil = reveilCheck.isSelected() ? parseHeure(timeField.getText()) : null;
        return new Saisie(modele,
                parseDStrict(valeurBaseField.getText()),
                parseHeure(heureField.getText()),
                parseDStrict(valeurMecField.getText()),
                prixAccessoire(boitierCheck, boitierPrix),
                prixAccessoire(braceletCheck, braceletPrix),
                prixAccessoire(fermoirCheck, fermoirPrix),
                prixAccessoire(vitreCheck, vitrePrix),
                date, reveil);
    }

    /** Parse strict d'un montant : null si invalide (format) — jamais de 0 silencieux.
     *  Rejette aussi NaN / Infinity ("1e309", "NaN") : seul un nombre FINI est accepté. */
    private Double parseDStrict(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        try {
            double v = Double.parseDouble(t.replace(",", "."));
            return Double.isFinite(v) ? v : null;
        } catch (NumberFormatException e) { return null; }
    }

    /** Prix d'un accessoire coché (null si le champ est invalide). */
    private Double prixAccessoire(javafx.scene.control.CheckBox cb, javafx.scene.control.TextField tf) {
        if (!cb.isSelected()) return 0.0;
        return parseDStrict(tf.getText());
    }

    private Mecanisme buildMecanisme(LocalTime h, double mv, LocalDate date, LocalTime reveil) {
        return switch (typeCombo.getValue()) {
            case TYPE_DIGITAL -> new MecanismeDigital(mv, h, reveil);
            case TYPE_DOUBLE  -> new MecanismeDouble(mv, h, date, reveil);
            default           -> new MecanismeAnalogique(mv, h, date);
        };
    }

    /** Applique les accessoires cochés (remplace la collection, avec copies défensives). */
    private void appliquerAccessoires(Montre m, Double boitier, Double bracelet, Double fermoir, Double vitre) {
        List<Accessoire> list = new ArrayList<>();
        if (boitierCheck.isSelected())  list.add(new Boitier(boitier));
        if (braceletCheck.isSelected()) list.add(new Bracelet(bracelet));
        if (fermoirCheck.isSelected())  list.add(new Fermoir(fermoir));
        if (vitreCheck.isSelected())    list.add(new Vitre(vitre));
        m.remplacerAccessoires(list);
    }

    private void updatePrix() {
        Saisie s = lireSaisie();
        if (s.valeurBase() == null || s.valeurMec() == null || s.heure() == null
                || s.boitier() == null || s.bracelet() == null || s.fermoir() == null || s.vitre() == null) {
            prixLabel.setText("— CHF");
            return;
        }
        try {
            // Modèle d'aperçu non vide : le constructeur valide le modèle (ép.6).
            Montre tmp = new Montre("aperçu", s.valeurBase(), buildMecanisme(s.heure(), s.valeurMec(), s.date(), s.reveil()));
            appliquerAccessoires(tmp, s.boitier(), s.bracelet(), s.fermoir(), s.vitre());
            prixLabel.setText(String.format("%.2f CHF", tmp.prix()));
        } catch (Exception e) { prixLabel.setText("— CHF"); }
    }

    @FXML
    private void handleValider() {
        Saisie s = lireSaisie();

        if (s.modele().isEmpty()) {
            marquerInvalide(modeleField);
            AlertHelper.error(dialogStage, "Champ requis", "- Le modèle est obligatoire."); return;
        }
        if (s.modele().length() > Montre.MODELE_MAX_LENGTH) {
            marquerInvalide(modeleField);
            AlertHelper.error(dialogStage, "Modèle trop long",
                    "- Le modèle ne peut pas dépasser " + Montre.MODELE_MAX_LENGTH + " caractères."); return;
        }
        if (s.heure() == null) {
            marquerInvalide(heureField);
            AlertHelper.error(dialogStage, "Heure invalide", "- Format attendu: HH:mm:ss"); return;
        }
        if (dateCheck.isSelected() && s.date() == null) {
            marquerInvalide(datePicker);
            AlertHelper.error(dialogStage, "Date requise",
                    "- La case « Date » est cochée : choisissez une date valide dans le sélecteur."); return;
        }
        if (reveilCheck.isSelected() && s.reveil() == null) {
            marquerInvalide(timeField);
            AlertHelper.error(dialogStage, "Réveil invalide",
                    "- La case « Réveil » est cochée : saisissez une heure valide (HH:mm ou HH:mm:ss)."); return;
        }
        if (s.valeurBase() == null || s.valeurMec() == null) {
            marquerInvalide(valeurBaseField);
            marquerInvalide(valeurMecField);
            AlertHelper.error(dialogStage, "Valeur invalide", "- Saisissez un nombre valide pour la valeur de base et le mécanisme."); return;
        }
        if (s.boitier() == null || s.bracelet() == null || s.fermoir() == null || s.vitre() == null) {
            if (s.boitier() == null)  marquerInvalide(boitierPrix);
            if (s.bracelet() == null) marquerInvalide(braceletPrix);
            if (s.fermoir() == null)  marquerInvalide(fermoirPrix);
            if (s.vitre() == null)    marquerInvalide(vitrePrix);
            AlertHelper.error(dialogStage, "Prix invalide", "- Saisissez un prix valide pour chaque accessoire coché."); return;
        }

        try {
            // نبني دائماً Montre جديدة (حتى عند التعديل) — لماذا؟
            // لأن valeurDeBase حقل نهائي (immuable) لا يمكن تغييره على كائن موجود،
            // فالنموذج الجديد هو الطريقة الوحيدة لالتقاط كل القيم الجديدة؛
            // وعند التعديل ننقل الـ id فقط (setId) ليتحول save() إلى UPDATE.
            Montre m = new Montre(s.modele(), s.valeurBase(),
                    buildMecanisme(s.heure(), s.valeurMec(), s.date(), s.reveil()));
            appliquerAccessoires(m, s.boitier(), s.bracelet(), s.fermoir(), s.vitre());
            if (montreToEdit == null) {
                catalogue.ajouter(m);
            } else {
                m.setId(montreToEdit.getId());      // conserve la clé => UPDATE
                catalogue.modifier(m);
            }
            resultMontre = m;
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            // قواعد العمل المخالفة (معرّفة مركزياً في الـ Service) — نعرض رسالتها.
            AlertHelper.error(dialogStage, "Données invalides", e.getMessage());
        } catch (RuntimeException e) {
            // فشل الحفظ (قاعدة غير متاحة، قيد SQL...) — نعرضها بلا تعطّل.
            AlertHelper.error(dialogStage, "Erreur de sauvegarde",
                    "L'enregistrement a échoué (base de données ?).\n" + e.getMessage());
        }
    }

    @FXML private void handleAnnuler() { dialogStage.close(); }

    /** Active/désactive les options Date et Réveil selon le type de mécanisme :
     *  Analogique → date ; Digital → réveil ; Double → les deux. */
    private void appliquerOptionsSelonType() {
        String type = typeCombo.getValue();
        boolean analog = TYPE_ANALOGIQUE.equals(type);
        boolean digital = TYPE_DIGITAL.equals(type);
        boolean doubleMec = TYPE_DOUBLE.equals(type);

        dateCheck.setDisable(!analog && !doubleMec);
        datePicker.setDisable(!analog && !doubleMec);
        reveilCheck.setDisable(!digital && !doubleMec);
        timeField.setDisable(!digital && !doubleMec);
    }

    /** Actualise l'aperçu du prix dès qu'un champ numérique change. */
    private void lierPrix(javafx.scene.control.TextField tf) {
        tf.textProperty().addListener((o, a, b) -> updatePrix());
    }

    /** Actualise l'aperçu du prix dès qu'une case à cocher change. */
    private void lierPrix(javafx.scene.control.CheckBox cb) {
        cb.selectedProperty().addListener((o, a, b) -> updatePrix());
    }

    /** Actualise l'aperçu du prix dès que la date choisie change. */
    private void lierPrix(DatePicker dp) {
        dp.valueProperty().addListener((o, a, b) -> updatePrix());
    }

    /** Marque visuellement un champ invalide (bordure rouge). */
    private void marquerInvalide(Control c) {
        if (c != null && !c.getStyleClass().contains("field-invalid")) c.getStyleClass().add("field-invalid");
    }

    /** Efface la marque d'erreur d'un champ. */
    private void effacerMarque(Control c) {
        if (c != null) c.getStyleClass().remove("field-invalid");
    }

    /** Efface la marque d'erreur dès que l'utilisateur saisit (validation inline). */
    private void effacerMarqueALaSaisie(javafx.scene.control.TextField tf) {
        if (tf != null) tf.textProperty().addListener((o, a, b) -> effacerMarque(tf));
    }

    private LocalTime parseHeure(String s) {
        if (s == null) return null;
        s = s.trim();
        try { return LocalTime.parse(s, HMS); }
        catch (Exception e) {
            try { return LocalTime.parse(s, HM); }
            catch (Exception e2) { return null; }
        }
    }
}
