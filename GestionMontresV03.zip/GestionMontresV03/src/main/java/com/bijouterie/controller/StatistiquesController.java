package com.bijouterie.controller;

import com.bijouterie.service.Catalogue;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * StatistiquesController — رسوم بيانية للكاطالوگ.
 *  • PieChart: توزيع الساعات حسب نوع الميكانيزم.
 *  • BarChart: الثمن الإجمالي لكل ساعة.
 *  التجميع كيتم فـ Service (Catalogue) — هذا الكلاس كيعرض النتائج فقط.
 */
public class StatistiquesController {

    @FXML private PieChart typeChart;
    @FXML private BarChart<String, Number> prixChart;
    @FXML private VBox chartsBox;
    @FXML private Label emptyLabel;

    private final Catalogue catalogue;

    /** Injection du service (Application Service) par le Composition Root (MainApp). */
    public StatistiquesController(Catalogue catalogue) {
        this.catalogue = catalogue;
    }

    @FXML
    private void initialize() {
        if (catalogue.getMontres().isEmpty()) {
            // حالة فارغة: لماذا نخفي الرسوم ونعرض رسالة بدل رسم بياني فارغ؟
            // الرسوم على كتالوج خالٍ لا معنى لها وقد توحي ببيانات صفرية خاطئة؛
            // رسالة واضحة توجه المستخدم لإضافة ساعات أولاً (أو إعادة التحميل).
            chartsBox.setVisible(false);
            chartsBox.setManaged(false);
            emptyLabel.setVisible(true);
            emptyLabel.setManaged(true);
            return;
        }

        // PieChart حسب النوع (agrégation déléguée au Service)
        Map<String, Integer> parType = catalogue.countByTypeMecanisme();
        for (var e : parType.entrySet())
            typeChart.getData().add(new PieChart.Data(e.getKey() + " (" + e.getValue() + ")", e.getValue()));

        // BarChart الثمن لكل ساعة (agrégation déléguée au Service).
        // prixParMontre() renvoie TOUTES les montres (ordre d'insertion), y compris
        // celles portant un modèle en double — d'où la liste et non une Map.
        // CategoryAxis fusionne deux Data de même catégorie : on suffixe le label
        // des doublons (« Rolex (2) ») pour que chaque montre reste un bar visible.
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Prix (CHF)");
        List<Map.Entry<String, Double>> parMontre = catalogue.prixParMontre();
        Set<String> labelsUtilises = new HashSet<>();
        for (var e : parMontre) {
            String label = e.getKey();
            int n = 2;
            while (!labelsUtilises.add(label))
                label = e.getKey() + " (" + n++ + ")";
            series.getData().add(new XYChart.Data<>(label, e.getValue()));
        }
        prixChart.getData().add(series);
    }
}
