package com.bijouterie.controller;

import com.bijouterie.MainApp;
import com.bijouterie.model.Montre;
import com.bijouterie.service.Catalogue;
import com.bijouterie.util.AlertHelper;
import com.bijouterie.util.ExcelExporter;
import com.bijouterie.util.PdfExporter;
import com.bijouterie.util.Theme;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * CatalogueController — المتحكم الرئيسي للكاطالوگ.
 *   • جدول الساعات + بحث فوري + بطاقات KPI
 *   • لوحة تفاصيل كتعرض toString المتعدد الأشكال للساعة المختارة
 *   • أزرار: جديدة / تعديل / Dupliquer (نسخ عميق) / حذف / تصدير / Dark Mode / إحصائيات
 */
public class CatalogueController {

    private static final DateTimeFormatter HMS = DateTimeFormatter.ofPattern("HH:mm:ss");

    @FXML private TextField searchField;
    @FXML private MenuItem themeMenuItem;
    @FXML private MenuBar menuBar;
    @FXML private Label dbWarningLabel;
    @FXML private Label lblTotalMontres;
    @FXML private Label lblValeurTotale;
    @FXML private Label lblPrixMoyen;

    @FXML private TableView<Montre> table;
    @FXML private TableColumn<Montre, String> modeleCol;
    @FXML private TableColumn<Montre, String> typeCol;
    @FXML private TableColumn<Montre, String> heureCol;
    @FXML private TableColumn<Montre, Number> accCol;
    @FXML private TableColumn<Montre, String> prixCol;

    @FXML private TextArea detailArea;

    private MainApp mainApp;
    private final Catalogue catalogue;

    /** Injection du service (Application Service) par le Composition Root (MainApp). */
    public CatalogueController(Catalogue catalogue) {
        this.catalogue = catalogue;
    }

    @FXML
    private void initialize() {
        // كنربطو المنيوهات (Fichier/Actions/Affichage) بالثيم: كل واحدة
        // كيديرو popup ديالها بروحها (Scene منفصلة)، فبلا هاد الربط تبقى
        // بألوان قديمة (أو نص غير مقروء) ملي كيتبدّل الوضع الليلي/النهاري.
        if (menuBar != null) Theme.bindMenuBar(menuBar);

        // ربط الأعمدة عبر lambdas (باش نخليو الموديل صافي بلا JavaFX Properties)
        modeleCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getModele()));
        typeCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().typeMecanisme()));
        heureCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(
                c.getValue().getMecanisme() != null ? c.getValue().getMecanisme().getHeure().format(HMS) : "—"));
        accCol.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().getAccessoires().size()));
        prixCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(String.format("%.2f CHF", c.getValue().prix())));

        // البحث في الذاكرة عبر FilteredList فوق قائمة Catalogue مباشرة.
        // لماذا لا استعلام DB عند كل ضغطة مفتاح؟ لأن الكتالوج محمّل كاملاً،
        // فالفلترة المباشرة لحظية بلا شبكة وبلا إبطاء، وتمتزج مع الفرز (SortedList).
        FilteredList<Montre> filtered = new FilteredList<>(catalogue.getMontres(), m -> true);
        if (searchField != null) {
            searchField.textProperty().addListener((o, a, q) -> {
                String s = q == null ? "" : q.toLowerCase(Locale.ROOT).trim();
                filtered.setPredicate(m -> s.isEmpty()
                        || (m.getModele() != null && m.getModele().toLowerCase(Locale.ROOT).contains(s))
                        || m.typeMecanisme().toLowerCase(Locale.ROOT).contains(s));
            });
        }
        SortedList<Montre> sorted = new SortedList<>(filtered);
        sorted.comparatorProperty().bind(table.comparatorProperty());
        table.setItems(sorted);

        // عند تغيّر الاختيار نعرض التفاصيل؛ وعند تغيّر القائمة (إضافة/حذف)
        // نحدّث بطاقات KPI — وهذا «ربط حي» دون تدخل يدوي بعد كل عملية.
        table.getSelectionModel().selectedItemProperty().addListener((o, ov, nv) -> showDetail(nv));
        catalogue.getMontres().addListener((javafx.collections.ListChangeListener<Montre>) ch -> updateKpis());

        if (!catalogue.getMontres().isEmpty()) table.getSelectionModel().selectFirst();
        updateDbWarning();
        updateKpis();
    }

    public void setMainApp(MainApp mainApp) { this.mainApp = mainApp; }

    private void showDetail(Montre m) {
        detailArea.setText(m == null ? "Sélectionnez une montre pour voir le détail…" : m.toString());
    }

    private void updateKpis() {
        Catalogue.CatalogueStats stats = catalogue.getStats(); // logique métier déléguée au Service
        if (lblTotalMontres != null) lblTotalMontres.setText(String.valueOf(stats.nbMontres()));
        if (lblValeurTotale != null) lblValeurTotale.setText(String.format("%,.0f CHF", stats.valeurTotale()));
        if (lblPrixMoyen != null)    lblPrixMoyen.setText(String.format("%,.0f CHF", stats.prixMoyen()));
    }

    private Montre selected() { return table.getSelectionModel().getSelectedItem(); }

    /** Bascule la visibilité de la bannière d'avertissement selon l'état de la base. */
    private void updateDbWarning() {
        if (dbWarningLabel == null) return;
        boolean failed = catalogue.isRefreshFailed();
        dbWarningLabel.setVisible(failed);
        dbWarningLabel.setManaged(failed);
    }

    /** Recharge le catalogue depuis la base (reprise après panne DB / changements externes). */
    @FXML
    private void handleRefresh() {
        catalogue.refresh();
        if (!catalogue.getMontres().isEmpty()) table.getSelectionModel().selectFirst();
        updateDbWarning();
        updateKpis();
        if (catalogue.isRefreshFailed()) {
            AlertHelper.warning(mainApp.getPrimaryStage(), "Base inaccessible",
                    "Le catalogue n'a pas pu être rechargé. Vérifiez que MySQL (XAMPP) est démarré, puis réessayez.");
        } else {
            AlertHelper.info(mainApp.getPrimaryStage(), "Catalogue rechargé",
                    catalogue.getMontres().size() + " montre(s) chargée(s).");
        }
    }

    @FXML
    private void handleClearSearch() {
        if (searchField != null) {
            searchField.clear();
            searchField.requestFocus();
        }
    }

    @FXML
    private void handleNouvelle() {
        Montre m = mainApp.showMontreDialog(null);
        if (m != null) table.getSelectionModel().select(m);
    }

    @FXML
    private void handleModifier() {
        Montre m = selected();
        if (m == null) { AlertHelper.warning(mainApp.getPrimaryStage(), "Aucune sélection", "Veuillez sélectionner une montre à modifier."); return; }
        Montre misAJour = mainApp.showMontreDialog(m);
        if (misAJour != null) {
            table.getSelectionModel().select(misAJour);
            showDetail(misAJour);
            updateKpis();
        }
    }

    /** Dupliquer = نسخ عميق (copie profonde). النسخة مستقلة تماماً. */
    @FXML
    private void handleDupliquer() {
        Montre m = selected();
        if (m == null) { AlertHelper.warning(mainApp.getPrimaryStage(), "Aucune sélection", "Veuillez sélectionner une montre à dupliquer."); return; }
        try {
            Montre copie = catalogue.dupliquer(m);
            table.getSelectionModel().select(copie);
            AlertHelper.info(mainApp.getPrimaryStage(), "Copie profonde",
                    "Une copie profonde indépendante a été créée :\n" + copie.getModele());
        } catch (RuntimeException e) {
            AlertHelper.error(mainApp.getPrimaryStage(), "Erreur de duplication",
                    "La duplication a échoué (base de données ?).\n" + e.getMessage());
        }
    }

    @FXML
    private void handleSupprimer() {
        Montre m = selected();
        if (m == null) { AlertHelper.warning(mainApp.getPrimaryStage(), "Aucune sélection", "Veuillez sélectionner une montre à supprimer."); return; }
        if (AlertHelper.confirm(mainApp.getPrimaryStage(), "Confirmation de suppression",
                "Voulez-vous vraiment supprimer la montre « " + m.getModele() + " » ?")) {
            try {
                catalogue.supprimer(m);
                showDetail(null); updateKpis();
            } catch (RuntimeException e) {
                AlertHelper.error(mainApp.getPrimaryStage(), "Erreur de suppression",
                        "La suppression a échoué (base de données ?).\n" + e.getMessage());
            }
        }
    }

    @FXML private void handleStatistiques() { mainApp.showStatistiques(); }

    @FXML
    private void handleToggleTheme() {
        Theme.toggle();
        if (themeMenuItem != null) themeMenuItem.setText(Theme.isDark() ? "☀ Mode clair" : "🌙 Mode sombre");
        // كنجبرو TableView يعاود يبني الخلايا ديالو من الصفر، باش ما تبقاش
        // أي خلية معاد استعمالها (virtualization) بستايل قديم عالق.
        if (table != null) table.refresh();
    }

    // ---- تصدير ----
    /** Exportateur (Excel ou PDF) : même protocole, format différent. */
    @FunctionalInterface
    private interface Exporteur {
        void exporter(File f) throws Exception;
    }

    /**
     * بروتوكول موحّد للتصدير (Excel/PDF): اختيار الملف ← تنفيذ ← إشعار النتيجة.
     * لماذا هذا التمرير بمعامل نوعه Exporteur؟ ليتجنّب تكرار كود «اختيار الملف
     * + معالجة الخطأ + رسالة النجاح» في كل زر؛ نمرّر فقط «كيفية التصدير».
     */
    private void exporter(String titre, String nomFichier, FileChooser.ExtensionFilter filtre, Exporteur e) {
        File f = chooseSaveFile(titre, nomFichier, filtre);
        if (f == null) return;
        try {
            e.exporter(f);
            AlertHelper.info(mainApp.getPrimaryStage(), "Export réussi", f.getAbsolutePath());
        } catch (Exception ex) {
            AlertHelper.error(mainApp.getPrimaryStage(), "Erreur d'export", ex.getMessage());
        }
    }

    private String[] exportHeaders() {
        return new String[]{"Modèle", "Type mécanisme", "Heure", "Nb accessoires", "Valeur base", "Prix total (CHF)"};
    }
    private List<String[]> exportRows() {
        List<String[]> rows = new ArrayList<>();
        for (Montre m : table.getItems()) {
            rows.add(new String[]{
                    m.getModele(), m.typeMecanisme(),
                    m.getMecanisme() != null ? m.getMecanisme().getHeure().format(HMS) : "—",
                    String.valueOf(m.getAccessoires().size()),
                    String.format("%.2f", m.getValeurDeBase()),
                    String.format("%.2f", m.prix())
            });
        }
        return rows;
    }

    @FXML
    private void handleExportExcel() {
        exporter("Exporter en Excel", "catalogue_montres.xlsx",
                new FileChooser.ExtensionFilter("Fichier Excel (*.xlsx)", "*.xlsx"),
                f -> ExcelExporter.export(f, "Montres", exportHeaders(), exportRows()));
    }

    @FXML
    private void handleExportPdf() {
        exporter("Exporter en PDF", "catalogue_montres.pdf",
                new FileChooser.ExtensionFilter("Fichier PDF (*.pdf)", "*.pdf"),
                f -> PdfExporter.export(f, "Catalogue des Montres", exportHeaders(), exportRows()));
    }

    private File chooseSaveFile(String title, String name, FileChooser.ExtensionFilter filter) {
        FileChooser fc = new FileChooser();
        fc.setTitle(title); fc.setInitialFileName(name); fc.getExtensionFilters().add(filter);
        return fc.showSaveDialog(mainApp.getPrimaryStage());
    }
}
