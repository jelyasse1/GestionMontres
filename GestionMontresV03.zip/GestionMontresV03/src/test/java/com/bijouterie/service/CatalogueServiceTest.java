package com.bijouterie.service;

import com.bijouterie.dao.MontreDAO;
import com.bijouterie.model.Boitier;
import com.bijouterie.model.Bracelet;
import com.bijouterie.model.MecanismeAnalogique;
import com.bijouterie.model.MecanismeDouble;
import com.bijouterie.model.Montre;
import com.bijouterie.model.Vitre;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests du service Catalogue (aucune base de données requise : fake DAO en mémoire).
 * Vérifie que les règles métier sont bien centralisées dans le Service :
 *  • validation des invariants (modèle, mécanisme, valeurs non négatives) ;
 *  • ajouter / modifier (en place) / supprimer / dupliquer ;
 *  • agrégations KPI (stats, type de mécanisme, prix par montre) ;
 *  • cas limites et erreurs.
 */
class CatalogueServiceTest {

    /** Fake DAO en mémoire : remplace MySQL dans les tests. */
    static class FakeMontreDAO implements MontreDAO {
        final List<Montre> db = new ArrayList<>();
        int nextId = 1;

        @Override public List<Montre> findAll() { return new ArrayList<>(db); }

        @Override public Montre save(Montre m) {
            if (m.getId() == 0) {
                m.setId(nextId++);
                db.add(m);
            }
            return m;
        }

        @Override public void delete(Montre m) { db.remove(m); }
    }

    /**
     * Fake DAO dont chaque opération peut échouer (simule MySQL indisponible /
     * violation de contrainte) : sert à prouver qu'un échec de persistance ne
     * laisse JAMAIS la liste observable du catalogue dans un état incohérent.
     */
    static class ThrowingFakeMontreDAO extends FakeMontreDAO {
        RuntimeException errorOnSaveInsert;
        RuntimeException errorOnSaveUpdate;
        RuntimeException errorOnDelete;
        RuntimeException errorOnFindAll;

        @Override public List<Montre> findAll() {
            if (errorOnFindAll != null) throw errorOnFindAll;
            return super.findAll();
        }

        @Override public Montre save(Montre m) {
            if (m.getId() == 0) {
                if (errorOnSaveInsert != null) throw errorOnSaveInsert;
            } else if (errorOnSaveUpdate != null) {
                throw errorOnSaveUpdate;
            }
            return super.save(m);
        }

        @Override public void delete(Montre m) {
            if (errorOnDelete != null) throw errorOnDelete;
            super.delete(m);
        }
    }

    private FakeMontreDAO dao;
    private Catalogue catalogue;

    private Montre montreValide(String modele) {
        Montre m = new Montre(modele, 120, new MecanismeAnalogique(80, LocalTime.of(10, 10),
                LocalDate.of(2025, 5, 17)));
        m.ajouterAccessoire(new Boitier(150));
        m.ajouterAccessoire(new Bracelet(90));
        return m;
    }

    @BeforeEach
    void setUp() {
        // ThrowingFakeMontreDAO : par défaut, aucune erreur active — se comporte
        // exactement comme FakeMontreDAO (les erreurs sont opt-in par test).
        dao = new ThrowingFakeMontreDAO();
        catalogue = new Catalogue(dao);
    }

    // ---------- Validation des règles métier ----------

    @Test
    void ajouter_valide_persisteEtAssigneUnId() {
        Montre m = montreValide("Classic Or");
        catalogue.ajouter(m);
        assertTrue(m.getId() != 0);
        assertEquals(1, catalogue.getMontres().size());
        assertEquals(1, dao.findAll().size());
    }

    @Test
    void ajouter_modeleVide_rejete() {
        assertThrows(IllegalArgumentException.class, () -> catalogue.ajouter(montreValide("")));
        assertThrows(IllegalArgumentException.class, () -> catalogue.ajouter(montreValide("   ")));
    }

    @Test
    void ajouter_sansMecanisme_rejete() {
        assertThrows(IllegalArgumentException.class,
                () -> catalogue.ajouter(new Montre("X", 100, null)));
    }

    @Test
    void ajouter_valeurDeBaseNegative_rejetee() {
        assertThrows(IllegalArgumentException.class,
                () -> catalogue.ajouter(new Montre("X", -5, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)))));
    }

    @Test
    void ajouter_mecanismeNegatif_rejete() {
        assertThrows(IllegalArgumentException.class,
                () -> catalogue.ajouter(new Montre("X", 100, new MecanismeAnalogique(-80, LocalDate.of(2025, 5, 17)))));
    }

    @Test
    void accessoireNegatif_rejete_parLeModele() {
        // L'invariant "valeur non négative" vit désormais dans le modèle (T6) :
        // plus aucun accessoire négatif ne peut être construit.
        assertThrows(IllegalArgumentException.class, () -> new Boitier(-10));
    }

    @Test
    void ajouter_null_rejete() {
        assertThrows(IllegalArgumentException.class, () -> catalogue.ajouter(null));
    }

    @Test
    void valider_neRejettePas_uneMontreConforme() {
        assertDoesNotThrow(() -> catalogue.validerMontre(montreValide("OK")));
    }

    // ---------- CRUD ----------

    @Test
    void modifier_remplaceEnPlace_preserveLIdentite() {
        Montre m = montreValide("Original");
        catalogue.ajouter(m);
        int id = m.getId();

        Montre nouvelle = new Montre("Modifiée", 300, new MecanismeDouble(160, LocalDate.of(2025, 5, 17),
                LocalTime.of(7, 30)));
        nouvelle.setId(id);
        nouvelle.remplacerAccessoires(List.of(new Vitre(80)));
        catalogue.modifier(nouvelle);

        assertEquals(1, catalogue.getMontres().size());
        assertEquals(1, dao.findAll().size());
        assertSame(nouvelle, catalogue.getMontres().get(0));
        assertEquals("Modifiée", catalogue.getMontres().get(0).getModele());
    }

    @Test
    void modifier_invalide_rejete() {
        Montre m = montreValide("A");
        catalogue.ajouter(m);
        // Invalide pour le Service (mécanisme absent) mais constructible par le modèle.
        Montre invalide = new Montre("A", 100, null);
        invalide.setId(m.getId());
        assertThrows(IllegalArgumentException.class, () -> catalogue.modifier(invalide));
        // l'original est resté intact
        assertEquals("A", catalogue.getMontres().get(0).getModele());
    }

    @Test
    void modifier_idInconnu_reajouteEnSecurite() {
        Montre m = new Montre("B", 200, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)));
        m.setId(999);
        catalogue.modifier(m);
        assertEquals(1, catalogue.getMontres().size());
        assertSame(m, catalogue.getMontres().get(0));
    }

    @Test
    void dupliquer_copieProfonde_independante() {
        Montre m = montreValide("Prestige");
        catalogue.ajouter(m);
        Montre copie = catalogue.dupliquer(m);
        assertTrue(copie.getId() != 0);
        assertNotEquals(m.getId(), copie.getId());
        assertEquals("Prestige (copie)", copie.getModele());
        assertEquals(2, catalogue.getMontres().size());

        // indépendance mémoire : muter la copie n'affecte pas l'original
        copie.getMecanisme().setHeure(LocalTime.of(0, 0));
        assertEquals(LocalTime.of(10, 10), m.getMecanisme().getHeure());
    }

    @Test
    void dupliquer_tronqueLeNom_a120Caracteres() {
        String base = "M".repeat(115); // + " (copie)" dépasse la colonne DB VARCHAR(120)
        Montre m = new Montre(base, 100, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)));
        catalogue.ajouter(m);
        Montre copie = catalogue.dupliquer(m);
        assertTrue(copie.getModele().length() <= 120);
        assertTrue(copie.getModele().endsWith(" (copie)"));
    }

    @Test
    void supprimer_retireDeLaListeEtDeLaBase() {
        Montre m = montreValide("A");
        catalogue.ajouter(m);
        catalogue.supprimer(m);
        assertEquals(0, catalogue.getMontres().size());
        assertEquals(0, dao.findAll().size());
    }

    @Test
    void refresh_relitDepuisLaBase() {
        catalogue.ajouter(montreValide("A"));
        dao.db.add(montreValide("B")); // insertion "externe" en base
        catalogue.refresh();
        assertEquals(2, catalogue.getMontres().size());
    }

    // ---------- Échec de persistance : la liste observable reste cohérente ----------
    // Garde-fous : si dao.save/delete échoue (MySQL éteint, violation de contrainte…),
    // l'exception se propage à l'UI (affichée en dialogue) mais le catalogue en
    // mémoire ne doit contenir NI l'objet non persisté, NI avoir perdu un objet existant.

    @Test
    void ajouter_echecDAO_etatCatalogueIntact() {
        ThrowingFakeMontreDAO tdao = new ThrowingFakeMontreDAO();
        tdao.errorOnSaveInsert = new RuntimeException("MySQL éteint");
        Catalogue c = new Catalogue(tdao);

        Montre m = montreValide("A");
        assertThrows(RuntimeException.class, () -> c.ajouter(m));
        assertEquals(0, c.getMontres().size());
        assertEquals(0, tdao.findAll().size());
    }

    @Test
    void modifier_echecDAO_etatCatalogueIntact() {
        ThrowingFakeMontreDAO tdao = new ThrowingFakeMontreDAO();
        Catalogue c = new Catalogue(tdao);
        Montre original = montreValide("A");
        c.ajouter(original);

        tdao.errorOnSaveUpdate = new RuntimeException("Violation de contrainte");
        Montre maj = montreValide("B");
        maj.setId(original.getId());
        assertThrows(RuntimeException.class, () -> c.modifier(maj));
        assertEquals(1, c.getMontres().size());
        assertSame(original, c.getMontres().get(0));
        assertEquals("A", c.getMontres().get(0).getModele());
    }

    @Test
    void supprimer_echecDAO_etatCatalogueIntact() {
        ThrowingFakeMontreDAO tdao = new ThrowingFakeMontreDAO();
        Catalogue c = new Catalogue(tdao);
        Montre m = montreValide("A");
        c.ajouter(m);

        tdao.errorOnDelete = new RuntimeException("MySQL éteint");
        assertThrows(RuntimeException.class, () -> c.supprimer(m));
        assertEquals(1, c.getMontres().size());
        assertSame(m, c.getMontres().get(0));
        assertEquals(1, tdao.findAll().size());
    }

    @Test
    void dupliquer_echecDAO_etatCatalogueIntact() {
        ThrowingFakeMontreDAO tdao = new ThrowingFakeMontreDAO();
        Catalogue c = new Catalogue(tdao);
        Montre m = montreValide("A");
        c.ajouter(m);

        tdao.errorOnSaveInsert = new RuntimeException("MySQL éteint");
        assertThrows(RuntimeException.class, () -> c.dupliquer(m));
        assertEquals(1, c.getMontres().size());
        assertSame(m, c.getMontres().get(0));
        assertEquals(1, tdao.findAll().size());
    }

    @Test
    void refresh_echec_conserveLesDonneesExistantes_etSignaleLEchec() {
        catalogue.ajouter(montreValide("A"));
        catalogue.ajouter(montreValide("B"));
        assertFalse(catalogue.isRefreshFailed());

        ((ThrowingFakeMontreDAO) dao).errorOnFindAll = new RuntimeException("MySQL éteint");
        assertDoesNotThrow(() -> catalogue.refresh());
        assertTrue(catalogue.isRefreshFailed());
        // Dégradation gracieuse : l'ancien contenu reste affiché (pas de vidage).
        assertEquals(2, catalogue.getMontres().size());
    }

    @Test
    void refresh_succes_reinitialiseLEtatDEchec() {
        ((ThrowingFakeMontreDAO) dao).errorOnFindAll = new RuntimeException("MySQL éteint");
        catalogue.refresh();
        assertTrue(catalogue.isRefreshFailed());

        ((ThrowingFakeMontreDAO) dao).errorOnFindAll = null;
        catalogue.refresh();
        assertFalse(catalogue.isRefreshFailed());
    }

    // ---------- Agrégations / règles de calcul ----------

    @Test
    void stats_correctes() {
        // 120 + 80 + 150 + 90 = 440 chacune
        catalogue.ajouter(montreValide("A"));
        catalogue.ajouter(montreValide("B"));
        Catalogue.CatalogueStats s = catalogue.getStats();
        assertEquals(2, s.nbMontres());
        assertEquals(880, s.valeurTotale(), 1e-9);
        assertEquals(440, s.prixMoyen(), 1e-9);
    }

    @Test
    void stats_vide_retourneZeros() {
        Catalogue.CatalogueStats s = catalogue.getStats();
        assertEquals(0, s.nbMontres());
        assertEquals(0, s.valeurTotale(), 1e-9);
        assertEquals(0, s.prixMoyen(), 1e-9);
    }

    @Test
    void countParTypeMecanisme_et_prixParMontre() {
        catalogue.ajouter(montreValide("A")); // Analogique => 440
        Montre d = new Montre("D", 200, new MecanismeDouble(160, LocalDate.of(2025, 5, 17),
                LocalTime.of(7, 30)));
        d.remplacerAccessoires(List.of(new Vitre(80)));
        catalogue.ajouter(d);                // Double => 440

        Map<String, Integer> parType = catalogue.countByTypeMecanisme();
        assertEquals(1, parType.get("Analogique"));
        assertEquals(1, parType.get("Double (Analogique + Digital)"));

        List<Map.Entry<String, Double>> parMontre = catalogue.prixParMontre();
        assertEquals(2, parMontre.size());
        assertEquals(Map.entry("A", 440.0), parMontre.get(0));
        assertEquals(Map.entry("D", 440.0), parMontre.get(1));
    }

    @Test
    void prixParMontre_modelesDupliques_toutesLesMontresRepresentees() {
        // « modele » n'est pas une identité : deux montres "Rolex" + une "Omega"
        // doivent donner TROIS entrées (l'ancienne Map écrasait la première Rolex).
        catalogue.ajouter(montreValide("Rolex"));                       // 440
        catalogue.ajouter(montreValide("Rolex"));                       // 440
        Montre omega = montreValide("Omega");
        omega.remplacerAccessoires(List.of(new Vitre(80)));             // 120+80+80 = 280
        catalogue.ajouter(omega);

        List<Map.Entry<String, Double>> parMontre = catalogue.prixParMontre();
        assertEquals(3, parMontre.size());
        assertEquals("Rolex", parMontre.get(0).getKey());
        assertEquals(440, parMontre.get(0).getValue(), 1e-9);
        assertEquals("Rolex", parMontre.get(1).getKey());
        assertEquals(440, parMontre.get(1).getValue(), 1e-9);
        assertEquals("Omega", parMontre.get(2).getKey());
        assertEquals(280, parMontre.get(2).getValue(), 1e-9);
    }
}
