package com.bijouterie.dao;

import com.bijouterie.dao.impl.MontreDAOImpl;
import com.bijouterie.database.DatabaseConnection;
import com.bijouterie.model.Boitier;
import com.bijouterie.model.Bracelet;
import com.bijouterie.model.Fermoir;
import com.bijouterie.model.MecanismeAnalogique;
import com.bijouterie.model.MecanismeDigital;
import com.bijouterie.model.MecanismeDouble;
import com.bijouterie.model.Montre;
import com.bijouterie.model.Vitre;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests du DAO réel (MontreDAOImpl) contre une vraie base SQL :
 * H2 en mémoire en mode MySQL (aucun serveur MySQL requis).
 *
 * Vérifie : schéma ↔ modèle (round-trip), accessoires, types de mécanisme,
 * DELETE CASCADE, et surtout la stratégie transactionnelle (rollback complet
 * en cas d'échec d'une écriture — pas de données partielles).
 *
 * Le pilote H2 est chargé par réflexion (Class.forName) : le module JPMS
 * n'a donc aucune dépendance compilée vers H2.
 */
class MontreDAOImplTest {

    private static final String URL = "jdbc:h2:mem:bijouterie;MODE=MySQL;DB_CLOSE_DELAY=-1";

    /** Schéma de test : mêmes colonnes que database_schema.sql, CHECK pour forcer les échecs. */
    private static final String DDL =
            "CREATE TABLE IF NOT EXISTS montre (" +
            " id_montre INT AUTO_INCREMENT PRIMARY KEY," +
            " modele VARCHAR(120) NOT NULL," +
            " valeur_base DOUBLE NOT NULL DEFAULT 0," +
            " mec_type VARCHAR(20) NOT NULL DEFAULT 'ANALOGIQUE'," +
            " mec_valeur_base DOUBLE NOT NULL DEFAULT 0," +
            " mec_heure TIME NOT NULL DEFAULT '12:00:00'," +
            " mec_date DATE NULL," +
            " mec_heure_reveil TIME NULL," +
            " CONSTRAINT chk_montre_valeur_base_non_neg CHECK (valeur_base >= 0)," +
            " CONSTRAINT chk_mec_valeur_base_non_neg CHECK (mec_valeur_base >= 0)" +
            ");" +
            "CREATE TABLE IF NOT EXISTS accessoire (" +
            " id_accessoire INT AUTO_INCREMENT PRIMARY KEY," +
            " id_montre INT NOT NULL," +
            " type VARCHAR(20) NOT NULL," +
            " valeur_base DOUBLE NOT NULL DEFAULT 0," +
            " CONSTRAINT fk_acc_montre FOREIGN KEY (id_montre) REFERENCES montre(id_montre) ON DELETE CASCADE," +
            " CONSTRAINT chk_acc_valeur_base_non_neg CHECK (valeur_base >= 0)," +
            // Plafond volontaire : permet de déclencher une violation DB (rollback)
            // avec une valeur valide pour le modèle (l'anti-négatif y vit désormais).
            " CONSTRAINT chk_acc_valeur_base_upper CHECK (valeur_base <= 1000)" +
            ");";

    /** Source de connexions de test : H2 en mémoire via JDBC standard. */
    static class H2DatabaseConnection implements DatabaseConnection {
        @Override public Connection getConnection() throws SQLException {
            return DriverManager.getConnection(URL, "sa", "");
        }
        @Override public void closePool() { }
    }

    private MontreDAO dao;

    @BeforeAll
    static void init() throws Exception {
        // Chargement du pilote H2 par réflexion : aucune référence compilée à H2.
        Class.forName("org.h2.Driver");
        try (Connection con = DriverManager.getConnection(URL, "sa", "")) {
            execDdl(con);
        }
    }

    @BeforeEach
    void setUp() {
        dao = new MontreDAOImpl(new H2DatabaseConnection());
    }

    @AfterEach
    void clean() throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, "sa", "");
             Statement st = con.createStatement()) {
            st.execute("DELETE FROM accessoire");
            st.execute("DELETE FROM montre");
        }
    }

    private static void execDdl(Connection con) throws SQLException {
        try (Statement st = con.createStatement()) {
            for (String s : DDL.split(";")) {
                String t = s.trim();
                if (!t.isEmpty()) st.execute(t);
            }
        }
    }

    private Montre montreDouble(String modele) {
        Montre m = new Montre(modele, 200, new MecanismeDouble(160, LocalTime.of(14, 45),
                LocalDate.of(2025, 5, 17), LocalTime.of(7, 30)));
        m.ajouterAccessoire(new Boitier(220));
        m.ajouterAccessoire(new Bracelet(140));
        return m;
    }

    private Montre montreAnalogique(String modele) {
        Montre m = new Montre(modele, 120, new MecanismeAnalogique(80, LocalTime.of(10, 10),
                LocalDate.of(2025, 5, 17)));
        m.ajouterAccessoire(new Vitre(40));
        return m;
    }

    // ---------- Round-trip schéma ↔ modèle ----------

    @Test
    void save_insert_assigneUnId_etPersisteTout() {
        Montre m = montreDouble("Prestige");
        dao.save(m);
        assertTrue(m.getId() > 0);

        List<Montre> all = dao.findAll();
        assertEquals(1, all.size());
        Montre loaded = all.get(0);
        assertEquals("Prestige", loaded.getModele());
        assertEquals(200, loaded.getValeurDeBase(), 1e-9);
        assertTrue(loaded.getMecanisme() instanceof MecanismeDouble);
        assertEquals(LocalTime.of(14, 45), loaded.getMecanisme().getHeure());
        assertEquals(LocalDate.of(2025, 5, 17), ((MecanismeDouble) loaded.getMecanisme()).getDate());
        assertEquals(LocalTime.of(7, 30), ((MecanismeDouble) loaded.getMecanisme()).getHeureReveil());
        assertEquals(2, loaded.getAccessoires().size());
        assertEquals(Boitier.class,  loaded.getAccessoires().get(0).getClass());
        assertEquals(Bracelet.class, loaded.getAccessoires().get(1).getClass());
        assertEquals(220, loaded.getAccessoires().get(0).getValeurDeBase(), 1e-9);
    }

    @Test
    void heureAvecSecondes_roundTrip() {
        dao.save(new Montre("D", 60, new MecanismeDigital(50, LocalTime.of(8, 30, 15), LocalTime.of(7, 0))));
        assertEquals(LocalTime.of(8, 30, 15), dao.findAll().get(0).getMecanisme().getHeure());
    }

    @Test
    void typesDeMecanisme_roundTrip() {
        dao.save(new Montre("An", 100, new MecanismeAnalogique(80, LocalTime.of(9, 0), LocalDate.of(2025, 5, 17))));
        dao.save(new Montre("Di", 100, new MecanismeDigital(50, LocalTime.of(9, 0), null)));
        dao.save(new Montre("Db", 100, new MecanismeDouble(160, LocalTime.of(9, 0), LocalDate.of(2025, 5, 17), null)));

        List<Montre> all = dao.findAll();
        assertEquals(3, all.size());
        assertTrue(all.get(0).getMecanisme() instanceof MecanismeAnalogique);
        assertEquals(LocalDate.of(2025, 5, 17), ((MecanismeAnalogique) all.get(0).getMecanisme()).getDate());
        assertTrue(all.get(1).getMecanisme() instanceof MecanismeDigital);
        assertNull(((MecanismeDigital) all.get(1).getMecanisme()).getHeureReveil());
        assertTrue(all.get(2).getMecanisme() instanceof MecanismeDouble);
        assertEquals(LocalDate.of(2025, 5, 17), ((MecanismeDouble) all.get(2).getMecanisme()).getDate());
        assertNull(((MecanismeDouble) all.get(2).getMecanisme()).getHeureReveil());
    }

    @Test
    void update_remplace_etResynchroniseLesAccessoires() {
        Montre m = montreAnalogique("A");
        dao.save(m);
        int id = m.getId();

        Montre maj = new Montre("A modifiée", 300, new MecanismeDigital(50, LocalTime.of(8, 30), LocalTime.of(6, 45)));
        maj.setId(id);
        maj.remplacerAccessoires(List.of(new Fermoir(60), new Vitre(80)));
        dao.save(maj);

        List<Montre> all = dao.findAll();
        assertEquals(1, all.size());
        Montre loaded = all.get(0);
        assertEquals("A modifiée", loaded.getModele());
        assertEquals(300, loaded.getValeurDeBase(), 1e-9);
        assertTrue(loaded.getMecanisme() instanceof MecanismeDigital);
        assertEquals(2, loaded.getAccessoires().size());
        assertEquals(Fermoir.class, loaded.getAccessoires().get(0).getClass());
        assertEquals(Vitre.class,   loaded.getAccessoires().get(1).getClass());
    }

    @Test
    void findAll_retournePlusieursMontres_TrieesParId() {
        dao.save(montreAnalogique("A"));
        dao.save(montreDouble("B"));
        List<Montre> all = dao.findAll();
        assertEquals(2, all.size());
        assertEquals("A", all.get(0).getModele());
        assertEquals("B", all.get(1).getModele());
    }

    @Test
    void delete_supprimeLaMontre_etSesAccessoiresParCascade() throws SQLException {
        Montre m = montreDouble("X");
        dao.save(m);
        int id = m.getId();
        dao.delete(m);

        assertEquals(0, dao.findAll().size());
        try (Connection con = DriverManager.getConnection(URL, "sa", "");
             PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM accessoire WHERE id_montre=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                assertEquals(0, rs.getInt(1));
            }
        }
    }

    // ---------- Stratégie transactionnelle (atomicité) ----------

    @Test
    void insert_echoue_Rollback_annuleLInsertionDeLaMontre() {
        Montre m = montreDouble("X");
        // Valeur positive mais > plafond CHECK du schéma => INSERT accessoire échoue.
        m.remplacerAccessoires(List.of(new Boitier(5000)));

        assertThrows(RuntimeException.class, () -> dao.save(m));

        // Aucune écriture partielle : la montre n'a pas été persistée.
        assertEquals(0, dao.findAll().size());
    }

    @Test
    void update_echoue_Rollback_preserveLesAnciennesDonnees() {
        Montre m = montreAnalogique("A");
        dao.save(m);
        int id = m.getId();

        Montre maj = new Montre("B", 100, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)));
        maj.setId(id);
        maj.remplacerAccessoires(List.of(new Boitier(5000))); // échec pendant la resynchronisation

        assertThrows(RuntimeException.class, () -> dao.save(maj));

        List<Montre> all = dao.findAll();
        assertEquals(1, all.size());
        assertEquals("A", all.get(0).getModele());        // UPDATE montre annulé
        assertEquals(120, all.get(0).getValeurDeBase(), 1e-9);
        assertEquals(1, all.get(0).getAccessoires().size()); // anciens accessoires intacts
    }

    @Test
    void delete_idInexistant_neLevePas() {
        Montre fantome = new Montre("Ghost", 0, new MecanismeAnalogique(0, LocalDate.of(2025, 5, 17)));
        fantome.setId(9999);
        assertDoesNotThrow(() -> dao.delete(fantome));
    }

    // ---------- Discriminateurs inconnus (données corrompues) ----------
    // Politique : un discriminateur inconnu/null est un échec EXPLICITE — le DAO
    // refuse d'inventer un type de domaine faux. Catalogue.refresh() intercepte
    // l'exception et active le bandeau d'échec (dégradation gracieuse côté UI).

    @Test
    void findAll_typeMecanismeInconnu_echecExplicite() throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, "sa", "");
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO montre(modele, valeur_base, mec_type, mec_valeur_base) "
                     + "VALUES (?, ?, ?, ?)")) {
            ps.setString(1, "Corrompue");
            ps.setDouble(2, 100);
            ps.setString(3, "TYPE_INEXISTANT");
            ps.setDouble(4, 50);
            ps.executeUpdate();
        }

        IllegalStateException ex = assertThrows(IllegalStateException.class, dao::findAll);
        assertTrue(ex.getMessage().contains("TYPE_INEXISTANT"), ex.getMessage());
        assertTrue(ex.getMessage().contains("Corrompue"), ex.getMessage());
    }

    @Test
    void findAll_typeAccessoireInconnu_echecExplicite() throws SQLException {
        Montre m = montreAnalogique("A");
        dao.save(m);
        try (Connection con = DriverManager.getConnection(URL, "sa", "");
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO accessoire(id_montre, type, valeur_base) VALUES (?, ?, ?)")) {
            ps.setInt(1, m.getId());
            ps.setString(2, "TYPE_INEXISTANT");
            ps.setDouble(3, 75);
            ps.executeUpdate();
        }

        IllegalStateException ex = assertThrows(IllegalStateException.class, dao::findAll);
        assertTrue(ex.getMessage().contains("TYPE_INEXISTANT"), ex.getMessage());
    }
}
