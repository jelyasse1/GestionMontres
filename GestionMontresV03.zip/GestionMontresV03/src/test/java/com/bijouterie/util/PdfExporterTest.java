package com.bijouterie.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests de PdfExporter (PDF construit à la main, sans dépendance).
 * Vérifie : structure PDF valide (header/xref/trailer), pagination
 * (nb de pages en fonction du nb de lignes), troncature des noms longs,
 * échappement des caractères spéciaux et accents CP1252.
 */
class PdfExporterTest {

    private static final Charset CP1252 = Charset.forName("windows-1252");

    @TempDir
    Path tempDir;

    private byte[] export(String[] headers, List<String[]> rows) throws IOException {
        File file = tempDir.resolve("catalogue.pdf").toFile();
        PdfExporter.export(file, "Catalogue des montres", headers, rows);
        return Files.readAllBytes(file.toPath());
    }

    private final String[] headers = {"Modèle", "Prix"};

    @Test
    void structurePdfValide() throws IOException {
        byte[] pdf = export(headers, List.<String[]>of(new String[] {"A", "100"}));
        String s = new String(pdf, CP1252);
        assertTrue(s.startsWith("%PDF-1.4"), "En-tête PDF absent");
        assertTrue(s.endsWith("%%EOF"), "Trailer %%EOF absent");
        assertTrue(s.contains("startxref"), "startxref absent");
        assertTrue(s.contains("/Count 1"), "1 page attendue");
    }

    @Test
    void pagination_plusieursPages_quandLesLignesDebordent() throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (int i = 1; i <= 100; i++) rows.add(new String[] {"Montre " + i, String.valueOf(i)});
        byte[] pdf = export(headers, rows);
        String s = new String(pdf, CP1252);

        // "/Type /Page " (espace final) ne matche PAS "/Type /Pages " (l'arbre).
        long pages = s.split("/Type /Page ", -1).length - 1;
        // 100 lignes à ~46/47 lignes par page (A4, pas de 15pt) => 3 pages.
        assertEquals(3, pages, "Pagination attendue : 3 pages pour 100 lignes");
        assertTrue(s.contains("/Count 3"), "Le dictionnaire Pages doit annoncer 3 pages");
        // Les parenthèses du flux sont échappées ( ligne\(s\) ) : on cherche sans elles.
        assertTrue(s.contains("Total: 100 ligne"), "Le total doit figurer sur la dernière page");
    }

    @Test
    void nomLong_tronque_sansException() throws IOException {
        String longNom = "M".repeat(300);
        byte[] pdf = export(headers, List.<String[]>of(new String[] {longNom, "100"}));
        String s = new String(pdf, CP1252);

        // Colonne plafonnée à 30 caractères : 29 caractères + « … ».
        String tronque = "M".repeat(29) + "…";
        assertTrue(s.contains(tronque), "Le nom doit être tronqué à 29 caractères + …");
        assertFalse(s.contains("M".repeat(30)), "Aucune ligne ne doit dépasser 30 caractères");
    }

    @Test
    void caracteresSpeciaux_echappes_accentucesEncodes() throws IOException {
        byte[] pdf = export(headers, List.<String[]>of(new String[] {
                "Boîte (or) \\Édition\\ été", "100"}));
        String s = new String(pdf, CP1252);

        // Échappement des délimiteurs de chaîne PDF
        assertTrue(s.contains("\\(") && s.contains("\\)") && s.contains("\\\\Édition\\\\"),
                "Les ( ) \\ doivent être échappés : " + s);
        // Accents français encodés en CP1252 (é = 0xE9)
        assertTrue(s.contains("été"), "Les accents doivent être encodés en CP1252");
        // Aucune parenthèse non échappée dans le flux : le PDF reste analysable
        assertTrue(s.endsWith("%%EOF"));
    }

    @Test
    void aucuneLigne_unePageAvecLeTotal() throws IOException {
        byte[] pdf = export(headers, List.of());
        String s = new String(pdf, CP1252);
        assertTrue(s.contains("Total: 0 ligne"));
        assertTrue(s.contains("/Count 1"));
    }

    @Test
    void caractereHorsWinAnsi_neCorromptPasLeFichier() throws IOException {
        // Limitation documentée : le PDF est encodé CP1252 (WinAnsi) ; un caractère
        // hors de ce jeu (ex. emoji, arabe) est remplacé par « ? » par l'encodeur.
        // Comportement volontairement préservé (dégradation gracieuse) : le fichier
        // reste un PDF valide, aucune exception, aucune donnée binaire invalide.
        byte[] pdf = export(headers, List.<String[]>of(new String[] {"Rolex ★ كوكب", "100"}));
        String s = new String(pdf, CP1252);
        assertTrue(s.startsWith("%PDF-1.4"));
        assertTrue(s.endsWith("%%EOF"));
        assertTrue(s.contains("Rolex ?"), "Hors WinAnsi => « ? » attendu");
        assertFalse(s.contains("★"), "Aucun caractère non encodable ne doit subsister");
    }
}
