package com.bijouterie.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests de ExcelExporter (xlsx construit à la main, sans dépendance).
 * Vérifie : validité ZIP, entrées attendues, échappement XML (cas de
 * corruption de fichier si un nom contient & < > "), valeurs null,
 * et les références de colonnes au-delà de Z (AA, AB…).
 */
class ExcelExporterTest {

    @TempDir
    Path tempDir;

    /** Exporte et retourne le XML de sheet1.xml (la seule feuille produite). */
    private String exportEtLireSheet(String sheetName, String[] headers,
                                     List<String[]> rows) throws IOException {
        File file = tempDir.resolve("catalogue.xlsx").toFile();
        ExcelExporter.export(file, sheetName, headers, rows);
        byte[] all = Files.readAllBytes(file.toPath());

        // 1) Le fichier est un ZIP valide avec exactement les entrées attendues.
        assertTrue(all.length > 4 && (all[0] == 'P' && all[1] == 'K'), "Signature ZIP (PK) absente");
        // (lecture des entrées au passage)
        String sheetXml = null;
        int entrees = 0;
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(file.toPath()))) {
            ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                entrees++;
                if ("xl/worksheets/sheet1.xml".equals(e.getName())) {
                    // readAllBytes lit jusqu'à la fin de l'entrée courante
                    // (sans fermer le flux partagé, contrairement à un try-with-resources imbriqué).
                    sheetXml = new String(zip.readAllBytes(), StandardCharsets.UTF_8);
                }
            }
        }
        assertEquals(5, entrees, "5 entrées attendues dans l'archive xlsx");
        assertNotNull(sheetXml);
        return sheetXml;
    }

    @Test
    void xml_echappeLesCaracteresSpeciaux() throws IOException {
        String[] headers = {"Modèle"};
        String sheet = exportEtLireSheet("Catalogue", headers, List.<String[]>of(new String[] {
                "Rolex & Fils <Luxe> \"Édition\" l'or é à ç"}));

        assertTrue(sheet.contains("Rolex &amp; Fils &lt;Luxe&gt; &quot;Édition&quot; l'or é à ç"), sheet);
        // Aucun caractère brut cassant le XML
        assertFalse(sheet.contains("Rolex & F"), sheet);
    }

    @Test
    void valeursNull_exporteesCommeCellulesVides() throws IOException {
        String sheet = exportEtLireSheet("Catalogue", new String[] {"A"},
                List.<String[]>of(new String[] {null}));
        assertTrue(sheet.contains("<t xml:space=\"preserve\"></t>"), sheet);
    }

    @Test
    void aucuneLigne_uneSeuleLigneDEntetes() throws IOException {
        String sheet = exportEtLireSheet("Catalogue", new String[] {"A", "B"}, List.of());
        assertEquals(1, sheet.split("<row ", -1).length - 1, "Seul le row d'en-têtes doit exister");
    }

    @Test
    void plusDe26Colonnes_referencesAA_AB() throws IOException {
        String[] headers = new String[27]; // A..Z puis AA
        for (int i = 0; i < 27; i++) headers[i] = "H" + i;
        String sheet = exportEtLireSheet("Catalogue", headers, List.of());
        assertTrue(sheet.contains("r=\"AA1\""), "La 27e colonne doit être référencée AA1 : " + sheet);
    }

    @Test
    void nomDeFeuille_echappe() throws IOException {
        File file = tempDir.resolve("catalogue.xlsx").toFile();
        ExcelExporter.export(file, "A<B&l'or", new String[] {"A"}, List.of());
        String workbook = lireEntree(file, "xl/workbook.xml");
        assertTrue(workbook.contains("name=\"A&lt;B&amp;l'or\""), workbook);
    }

    @Test
    void caracteresDeControleXML_invalides_retires() throws IOException {
        // XML 1.0 interdit les C0 (\u0000-\u0008, \u000B, \u000C, \u000E-\u001F)
        // hors \t \n \r : sans nettoyage, le classeur produit serait refusé par Excel.
        String sale = "A\u0000B\u0002C\u000BD\u001F\tE\nF\rG";
        String sheet = exportEtLireSheet("Catalogue", new String[] {"A"},
                List.<String[]>of(new String[] {sale}));
        assertTrue(sheet.contains("A\u0000B") == false, sheet);
        assertFalse(sheet.contains("\u000B") || sheet.contains("\u001F"), sheet);
        assertTrue(sheet.contains("\tE\nF\rG"), "Tab/ LF/ CR restent acceptés : " + sheet);
    }

    private String lireEntree(File file, String name) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(file.toPath()))) {
            ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                if (name.equals(e.getName())) {
                    return new String(zip.readAllBytes(), StandardCharsets.UTF_8);
                }
            }
        }
        return null;
    }
}
