package com.bijouterie.util;

import javafx.application.Platform;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test du Theme (outil JavaFX réel — pas headless si l'environnement a un affichage).
 *
 * Vérifie le contrat critique du workaround "inline style" des MenuItems :
 * la couleur forcée doit venir du token -ink de la feuille de style
 * (.root / .root.dark), pas d'une constante dupliquée dans le code Java.
 * Si un jour -ink change dans styles.css, ce test casse — c'est voulu :
 * c'est lui qui garantit la source unique de vérité.
 */
class ThemeTest {

    @Test
    void bindMenuBar_forceLaCouleurInk_resolueDepuisLaFeuilleDeStyle() throws Exception {
        // Démarre le toolkit JavaFX ; si l'environnement est headless, on saute
        // le test (Assumption) plutôt que de le faire échouer.
        CountDownLatch started = new CountDownLatch(1);
        Platform.startup(started::countDown);
        assertTrue(started.await(15, TimeUnit.SECONDS), "Toolkit JavaFX non démarré");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<String> styleLight = new AtomicReference<>();
        AtomicReference<String> styleDark = new AtomicReference<>();
        AtomicReference<Throwable> erreur = new AtomicReference<>();

        Platform.runLater(() -> {
            try {
                MenuItem item = new MenuItem("Élément de test");
                MenuBar bar = new MenuBar(new Menu("Fichier", null, item));

                Theme.bindMenuBar(bar);                       // mode clair (état initial)
                styleLight.set(item.getStyle());

                Theme.toggle();                               // -> mode sombre
                styleDark.set(item.getStyle());

                Theme.toggle();                               // retour au mode clair initial
            } catch (Throwable t) {
                erreur.set(t);
            } finally {
                done.countDown();
            }
        });
        assertTrue(done.await(15, TimeUnit.SECONDS), "Le test FX n'a pas abouti (timeout)");
        if (erreur.get() != null) fail("Erreur pendant le test FX", erreur.get());

        // Valeurs attendues = définition des tokens -ink dans styles.css
        // (.root -> #0f172a, .root.dark -> #e5e7eb). Si ces valeurs changent
        // dans la feuille de style, mettre à jour ce test en même temps.
        assertNotNull(styleLight.get());
        assertTrue(styleLight.get().contains("#0f172a"),
                "Couleur claire attendue #0f172a (token -ink), obtenu : " + styleLight.get());
        assertNotNull(styleDark.get());
        assertTrue(styleDark.get().contains("#e5e7eb"),
                "Couleur sombre attendue #e5e7eb (token -ink du .root.dark), obtenu : " + styleDark.get());
    }
}
