package com.bijouterie.model;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Modifier;
import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests du modèle Mecanisme (ép.3):
 *  • heure par défaut 12:00:00 ;
 *  • schéma d'affichage FINAL "type — cadran — prix" ;
 *  • affichage cadran spécifique par sous-classe ;
 *  • polymorphisme (Analogique / Digital) et copie typée.
 */
class MecanismeTest {

    @Test
    void heureParDefaut_12h_pourToutesLesSousClasses() {
        assertEquals(LocalTime.of(12, 0, 0),
                new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)).getHeure());
        assertEquals(LocalTime.of(12, 0, 0),
                new MecanismeDigital(50, LocalTime.of(7, 30)).getHeure());
        assertEquals(LocalTime.of(12, 0, 0),
                new MecanismeDouble(160, LocalDate.of(2025, 5, 17), LocalTime.of(7, 30)).getHeure());
    }

    @Test
    void heureExplicite_respectee() {
        assertEquals(LocalTime.of(10, 10, 0),
                new MecanismeAnalogique(80, LocalTime.of(10, 10), LocalDate.of(2025, 5, 17)).getHeure());
    }

    @Test
    void toString_suitLeSchemaFinal_type_cadran_prix() {
        Mecanisme analogique = new MecanismeAnalogique(80, LocalTime.of(10, 10), LocalDate.of(2025, 5, 17));
        String s = analogique.toString();
        assertTrue(s.startsWith("Mécanisme analogique — "), s);
        assertTrue(s.contains("aiguilles"), s);
        assertTrue(s.endsWith("— 80.00 CHF"), s);
    }

    @Test
    void toString_double_afficheLesDeuxRepresentations() {
        MecanismeDouble d = new MecanismeDouble(160, LocalTime.of(14, 45),
                LocalDate.of(2025, 5, 17), LocalTime.of(7, 30));
        String s = d.toString();
        assertTrue(s.startsWith("Mécanisme double (analogique + digital) — "), s);
        assertTrue(s.contains("aiguilles"), s);
        assertTrue(s.contains("🔢"), s);
        assertTrue(s.contains("|"), s);
        assertTrue(s.endsWith("— 160.00 CHF"), s);
    }

    @Test
    void toStringCadran_parDefaut_afficheLHeure() {
        // Sous-classe anonyme qui n'override PAS toStringCadran : on vérifie le défaut "heure HH:mm:ss".
        Mecanisme m = new Mecanisme(50, LocalTime.of(9, 30, 45)) {
            @Override public String typeLabel()          { return "test"; }
            @Override public Mecanisme copie()           { return this; }
        };
        assertTrue(m.toString().contains("heure 09:30:45"), m.toString());
    }

    @Test
    void heureNull_rejeteeConvertisseur_etSetHeure() {
        // Invariant : l'heure est obligatoire (affichée sans garde par toStringCadran
        // et par l'affichage digital ; NOT NULL en base ; l'UI la traite comme
        // saisie invalide). Contraire à heureReveil, nullable par conception.
        assertThrows(IllegalArgumentException.class,
                () -> new MecanismeAnalogique(80, null, null));
        assertThrows(IllegalArgumentException.class,
                () -> new MecanismeDigital(50, null, null));
        assertThrows(IllegalArgumentException.class,
                () -> new MecanismeDouble(160, null, null, null));

        Mecanisme m = new MecanismeDigital(50, LocalTime.of(8, 0), null);
        assertThrows(IllegalArgumentException.class, () -> m.setHeure(null));
        // L'heure valide existante n'est pas altérée par le rejet.
        assertEquals(LocalTime.of(8, 0), m.getHeure());
    }

    @Test
    void prix_dUnMecanisme_estSaValeurDeBase() {
        assertEquals(160.0, new MecanismeDouble(160, LocalDate.of(2025, 5, 17), LocalTime.of(7, 30)).prix(), 1e-9);
    }

    @Test
    void mecanismeDouble_estAnalogue_et_digital() {
        MecanismeDouble d = new MecanismeDouble(160, LocalDate.of(2025, 5, 17), LocalTime.of(7, 30));
        Analogique a = d;   // compile : il EST analogique (hérité)
        Digital    di = d;  // compile : il EST digital (interface)
        assertTrue(a.afficheAnalogique().contains("aiguilles"));
        assertTrue(di.afficheDigital().contains("🔢"));
    }

    @Test
    void copie_conserveLeTypeReel() {
        assertTrue(new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)).copie() instanceof MecanismeAnalogique);
        assertTrue(new MecanismeDigital(50, LocalTime.of(7, 30)).copie() instanceof MecanismeDigital);
        assertTrue(new MecanismeDouble(160, LocalDate.of(2025, 5, 17), null).copie() instanceof MecanismeDouble);
    }

    @Test
    void mecanismeDouble_estAvantTout_unMecanismeAnalogique() {
        MecanismeDouble d = new MecanismeDouble(160, LocalDate.of(2025, 5, 17), LocalTime.of(7, 30));
        assertTrue(d instanceof MecanismeAnalogique);
        assertTrue(d instanceof Mecanisme);
    }

    @Test
    void toString_deMecanisme_estFinal_schemaImpose() throws Exception {
        assertTrue(Modifier.isFinal(
                Mecanisme.class.getMethod("toString").getModifiers()));
    }

    @Test
    void affichages_sansDate_sansReveil() {
        String analog = new MecanismeAnalogique(80, LocalTime.of(10, 0), null).afficheAnalogique();
        assertTrue(analog.contains("aiguilles"), analog);
        assertFalse(analog.contains("📅"), analog);

        String digital = new MecanismeDigital(50, LocalTime.of(8, 0), null).afficheDigital();
        assertTrue(digital.contains("🔢"), digital);
        assertFalse(digital.contains("⏰"), digital);

        String doubleSansOptions = new MecanismeDouble(160, LocalTime.of(9, 0), null, null).afficheDigital();
        assertFalse(doubleSansOptions.contains("⏰"), doubleSansOptions);
    }
}
