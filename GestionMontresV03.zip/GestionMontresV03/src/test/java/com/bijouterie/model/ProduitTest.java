package com.bijouterie.model;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests de Produit / Accessoire :
 *  • immutabilité de valeurDeBase (ép.1) et nom (ép.2) ;
 *  • polymorphisme prix() via une référence Produit ;
 *  • copie typée d'un accessoire.
 */
class ProduitTest {

    @Test
    void accessoire_estUnProduit() {
        Accessoire b = new Bracelet(90);
        assertTrue(b instanceof Produit);
        assertEquals(90, b.prix(), 1e-9);
    }

    @Test
    void accessoire_aUnNomFixe() {
        assertEquals("Boîtier",  new Boitier(150).getNom());
        assertEquals("Bracelet", new Bracelet(90).getNom());
        assertEquals("Fermoir",  new Fermoir(60).getNom());
        assertEquals("Vitre",    new Vitre(80).getNom());
    }

    @Test
    void valeurDeBase_estImmuableApresConstruction() {
        Boitier b = new Boitier(150);
        assertEquals(150, b.getValeurDeBase());
        // Plus de setter : l'immutabilité est garantie à la compilation.
    }

    @Test
    void prix_polymorphe_viaReferenceProduit() {
        Produit p = new Vitre(80);
        assertEquals(80, p.prix(), 1e-9);
    }

    @Test
    void toString_accessoire_contientNomEtPrix() {
        String s = new Bracelet(90).toString();
        assertTrue(s.contains("Bracelet"));
        assertTrue(s.contains("90.00 CHF"));
    }

    @Test
    void copieAccessoire_conserveLeTypeReel() {
        Boitier b = new Boitier(150);
        Produit copie = b.copie();
        assertTrue(copie instanceof Boitier);
        assertEquals(150, copie.prix(), 1e-9);
    }

    @Test
    void produit_estAbstrait() {
        assertTrue(Modifier.isAbstract(Produit.class.getModifiers()));
    }

    @Test
    void valeurDeBase_estUnAttributFinal() throws Exception {
        assertTrue(Modifier.isFinal(
                Produit.class.getDeclaredField("valeurDeBase").getModifiers()));
    }

    @Test
    void nom_accessoire_estFinal() throws Exception {
        assertTrue(Modifier.isFinal(
                Accessoire.class.getDeclaredField("nom").getModifiers()));
    }

    @Test
    void toString_viaReferenceProduit_adapteAuTypeReel() {
        Produit p = new Boitier(150);
        assertTrue(p.toString().contains("Boîtier"));
        assertTrue(p.toString().contains("150.00 CHF"));
    }
}
