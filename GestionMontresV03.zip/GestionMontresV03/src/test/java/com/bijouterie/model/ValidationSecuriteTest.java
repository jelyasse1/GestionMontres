package com.bijouterie.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests de sécurité / robustesse (PHASE 4) :
 *  • les prix doivent être des nombres FINIS non négatifs (NaN / Infinity rejetés) ;
 *  • le modèle est obligatoire, non blanc et limité à 120 caractères (colonne DB) ;
 *  • les identifiants ne peuvent pas être négatifs ;
 *  • la validation vit dans le MODÈLE (pas seulement l'interface).
 */
class ValidationSecuriteTest {

    // ---------- Prix : nombres finis non négatifs ----------

    @Test
    void produit_rejette_NaN() {
        assertThrows(IllegalArgumentException.class, () -> new Boitier(Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> new Vitre(Double.NaN));
    }

    @Test
    void produit_rejette_Infini() {
        assertThrows(IllegalArgumentException.class, () -> new Bracelet(Double.POSITIVE_INFINITY));
        assertThrows(IllegalArgumentException.class, () -> new Fermoir(Double.NEGATIVE_INFINITY));
    }

    @Test
    void produit_rejette_Negatif() {
        assertThrows(IllegalArgumentException.class, () -> new Boitier(-1));
    }

    @Test
    void produit_accepte_zero_etValeursFinies() {
        assertDoesNotThrow(() -> new Boitier(0));
        assertDoesNotThrow(() -> new Boitier(1e308));
    }

    @Test
    void mecanisme_rejette_prixNonFini() {
        assertThrows(IllegalArgumentException.class,
                () -> new MecanismeAnalogique(Double.NaN, LocalTime.of(10, 0), LocalDate.of(2025, 5, 17)));
        assertThrows(IllegalArgumentException.class,
                () -> new MecanismeDigital(Double.POSITIVE_INFINITY, LocalTime.of(10, 0), LocalTime.of(7, 0)));
    }

    @Test
    void montre_rejette_valeurBaseNonFinie() {
        assertThrows(IllegalArgumentException.class,
                () -> new Montre("X", Double.NaN, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17))));
        assertThrows(IllegalArgumentException.class,
                () -> new Montre("X", Double.POSITIVE_INFINITY, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17))));
    }

    // ---------- Modèle : obligatoire / non blanc / longueur ----------

    @Test
    void montre_rejette_modeleNull_ouVide() {
        assertThrows(IllegalArgumentException.class, () -> new Montre(null, 100, mecanisme()));
        assertThrows(IllegalArgumentException.class, () -> new Montre("", 100, mecanisme()));
    }

    @Test
    void montre_rejette_modeleBlanc() {
        assertThrows(IllegalArgumentException.class, () -> new Montre("   ", 100, mecanisme()));
        assertThrows(IllegalArgumentException.class, () -> new Montre("\t\n", 100, mecanisme()));
    }

    @Test
    void montre_rejette_modeleTropLong() {
        assertThrows(IllegalArgumentException.class, () -> new Montre("X".repeat(121), 100, mecanisme()));
        assertThrows(IllegalArgumentException.class, () -> new Montre("X".repeat(200), 100, mecanisme()));
    }

    @Test
    void montre_accepte_modeleExactement120() {
        assertDoesNotThrow(() -> new Montre("X".repeat(120), 100, mecanisme()));
    }

    @Test
    void setModele_appliqueLesMemesRegles() {
        Montre m = new Montre("OK", 100, mecanisme());
        assertThrows(IllegalArgumentException.class, () -> m.setModele(""));
        assertThrows(IllegalArgumentException.class, () -> m.setModele("   "));
        assertThrows(IllegalArgumentException.class, () -> m.setModele("X".repeat(121)));
        assertDoesNotThrow(() -> m.setModele("Bien"));
    }

    // ---------- Identifiants ----------

    @Test
    void setId_rejette_lesNegatifs() {
        Montre m = new Montre("X", 100, mecanisme());
        assertThrows(IllegalArgumentException.class, () -> m.setId(-1));
        assertDoesNotThrow(() -> m.setId(0));
        assertDoesNotThrow(() -> m.setId(42));
    }

    private static Mecanisme mecanisme() {
        return new MecanismeAnalogique(80, LocalTime.of(10, 0), LocalDate.of(2025, 5, 17));
    }
}
