package com.bijouterie.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests de Montre (ép.4 — anti-fuite d'encapsulation):
 *  • copie défensive du mécanisme et des accessoires ;
 *  • vue non modifiable des accessoires ;
 *  • prix() polymorphique = base + mécanisme + accessoires ;
 *  • copie() profonde et indépendante ;
 *  • remplacerAccessoires() (utilisé à l'édition).
 */
class MontreTest {

    private Montre montreCompleter() {
        Montre m = new Montre("Prestige", 200, new MecanismeDouble(160, LocalTime.of(14, 45),
                LocalDate.of(2025, 5, 17), LocalTime.of(7, 30)));
        m.ajouterAccessoire(new Boitier(220));
        m.ajouterAccessoire(new Bracelet(140));
        m.ajouterAccessoire(new Fermoir(60));
        m.ajouterAccessoire(new Vitre(80));
        return m;
    }

    @Test
    void prix_estLaSommePolymorphique() {
        assertEquals(200 + 160 + 220 + 140 + 60 + 80, montreCompleter().prix(), 1e-9);
    }

    @Test
    void prix_viaReferenceProduit() {
        Produit p = montreCompleter();
        assertEquals(p.prix(), ((Montre) p).prix(), 1e-9);
    }

    @Test
    void constructeur_copieLeMecanisme_antiFuite() {
        MecanismeDouble externe = new MecanismeDouble(160, LocalTime.of(14, 45),
                LocalDate.of(2025, 5, 17), LocalTime.of(7, 30));
        Montre m = new Montre("P", 200, externe);
        assertNotSame(externe, m.getMecanisme());
        // muter l'objet externe ne doit pas affecter la montre
        externe.setHeure(LocalTime.of(1, 1));
        assertEquals(LocalTime.of(14, 45), m.getMecanisme().getHeure());
    }

    @Test
    void ajouterAccessoire_ajouteUneCopie() {
        Montre m = new Montre("P", 200, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)));
        Boitier externe = new Boitier(150);
        m.ajouterAccessoire(externe);
        assertEquals(1, m.getAccessoires().size());
        assertNotSame(externe, m.getAccessoires().get(0));
        assertEquals(150, m.getAccessoires().get(0).getValeurDeBase());
    }

    @Test
    void getAccessoires_estNonModifiable() {
        Montre m = montreCompleter();
        assertThrows(UnsupportedOperationException.class, () -> m.getAccessoires().add(new Boitier(1)));
        assertThrows(UnsupportedOperationException.class, () -> m.getAccessoires().clear());
    }

    @Test
    void copieProfonde_estIndependante() {
        Montre m = montreCompleter();
        Montre c = m.copie();
        assertNotSame(m, c);
        assertNotSame(m.getMecanisme(), c.getMecanisme());
        for (int i = 0; i < m.getAccessoires().size(); i++) {
            assertNotSame(m.getAccessoires().get(i), c.getAccessoires().get(i));
        }
        assertEquals(m.prix(), c.prix(), 1e-9);

        // muter la copie => l'original reste intact
        c.getMecanisme().setHeure(LocalTime.of(0, 0));
        assertEquals(LocalTime.of(14, 45), m.getMecanisme().getHeure());
    }

    @Test
    void copie_preserveLeTypeReelDesAccessoires() {
        Montre c = montreCompleter().copie();
        assertEquals(Boitier.class,  c.getAccessoires().get(0).getClass());
        assertEquals(Bracelet.class, c.getAccessoires().get(1).getClass());
        assertEquals(Fermoir.class,  c.getAccessoires().get(2).getClass());
        assertEquals(Vitre.class,    c.getAccessoires().get(3).getClass());
    }

    @Test
    void remplacerAccessoires_remplaceAvecDesCopies() {
        Montre m = new Montre("P", 200, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)));
        m.remplacerAccessoires(List.of(new Boitier(1), new Vitre(2)));
        assertEquals(2, m.getAccessoires().size());
        assertEquals(Boitier.class, m.getAccessoires().get(0).getClass());
        assertEquals(Vitre.class,   m.getAccessoires().get(1).getClass());
    }

    @Test
    void montreSansMecanisme_prixSansPartieMecanisme() {
        Montre m = new Montre("P", 100, null);
        m.ajouterAccessoire(new Boitier(50));
        assertEquals(150, m.prix(), 1e-9);
    }

    @Test
    void toString_contientModeleEtPrixTotal() {
        String s = montreCompleter().toString();
        assertTrue(s.contains("Prestige"));
        assertTrue(s.contains("PRIX TOTAL"));
        assertTrue(s.contains("860.00 CHF"));
    }

    @Test
    void toString_viaReferenceProduit_afficheLaMontre() {
        Produit p = montreCompleter();
        String s = p.toString();
        assertTrue(s.contains("Prestige"));
        assertTrue(s.contains("PRIX TOTAL"));
        assertTrue(s.contains("860.00 CHF"));
    }

    @Test
    void toString_sansAccessoires_afficheAucun() {
        Montre m = new Montre("Minimal", 100, new MecanismeAnalogique(80, LocalDate.of(2025, 5, 17)));
        String s = m.toString();
        assertTrue(s.contains("(aucun)"), s);
        assertTrue(s.contains("PRIX TOTAL"), s);
        assertTrue(s.contains("180.00 CHF"), s);
    }
}
