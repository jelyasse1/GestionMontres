-- ============================================================================
--  MIGRATION — PHASE 3/4 : MODEL OOP HARDENING (Task 2)
-- ============================================================================
--  Contexte : les mécanismes modélisaient les options "date affichée" et
--  "réveil" par des BOOLEAN. La phase "MODEL OOP HARDENING" les a remplacées
--  par de VRAIES valeurs métier :
--     • MecanismeAnalogique / MecanismeDouble : LocalDate date  (null = pas de date)
--     • MecanismeDigital / MecanismeDouble    : LocalTime heureReveil (null = pas de réveil)
--  => les colonnes TINYINT(1) deviennent DATE / TIME, NULLables.
--
--  ATTENTION : fichier écrit mais NON APPLIQUÉ (aucun serveur MySQL dans
--  l'environnement). À exécuter manuellement sur le serveur de production
--  AVANT de déployer la nouvelle version du code.
--
--  Usage :
--      mysql -u <user> -p <bijouterie> < migration_20250830_mec_date_reveil.sql
--  Ou dans une console mysql :
--      SOURCE migration_20250830_mec_date_reveil.sql;
--
--  NOTE : la colonne TYPE_DATE (contenu de mec_date) perd les valeurs
--  historiques TINYINT (0/1). Les données existantes "date affichée" / "réveil"
--  ne sont PAS transposables de façon sûre en DATE/TIME (aucune date/heure
--  historique encodée). Les montres existantes auront donc date=null /
--  heureReveil=null (option désactivée) après migration.
-- ============================================================================

-- 1) Remplacer la colonne "date affichée" (booléen) par une vraie DATE (nullable).
ALTER TABLE montre
    DROP COLUMN mec_date_affichee;

ALTER TABLE montre
    ADD COLUMN mec_date DATE NULL AFTER mec_heure;

-- 2) Remplacer la colonne "réveil" (booléen) par une vraie TIME (nullable).
ALTER TABLE montre
    DROP COLUMN mec_reveil;

ALTER TABLE montre
    ADD COLUMN mec_heure_reveil TIME NULL AFTER mec_date;

-- 3) Cohérence : le mécanisme analogique seul ne devrait pas porter de réveil,
--    le mécanisme digital seul ne devrait pas porter de date. Ces contraintes
--    sont laissées au niveau applicatif (le DAO lit/écrit selon le type).
--    (Ajout de contraintes CHECK cross-colonnes déconseillé : les données
--     héritées de l'ancien schéma n'y satisferaient pas.)

-- 4) Index existant conservé (aucun changement de clé primaire).
--    Vérification rapide :
--       SHOW COLUMNS FROM montre;
